import axios, { AxiosError } from "axios";
import {
  BURO_API_CONFIG,
  AuthenticatorRequest,
  BureauReportRequest,
  IncomeEstimatorRequest,
  BuroApiResponse,
} from "./buro-api-config";

/**
 * Servicio para integración con APIs de Buró de Crédito
 */
export class BuroApiService {
  private apiKey: string;
  private apiSecret: string;
  private baseUrl: string;

  constructor() {
    this.apiKey = BURO_API_CONFIG.apiKey;
    this.apiSecret = BURO_API_CONFIG.apiSecret;
    this.baseUrl = BURO_API_CONFIG.baseUrl;
  }

  /**
   * Crear headers de autenticación básica
   */
  private getAuthHeaders(): Record<string, string> {
    const credentials = Buffer.from(`${this.apiKey}:${this.apiSecret}`).toString(
      "base64"
    );
    return {
      "Content-Type": "application/json",
      Authorization: `Basic ${credentials}`,
      "X-API-Key": this.apiKey,
    };
  }

  /**
   * Manejar errores de API
   */
  private handleApiError(error: unknown, context: string): {
    success: false;
    error: string;
    code: string;
    details?: unknown;
  } {
    if (axios.isAxiosError(error)) {
      const axiosError = error as AxiosError<any>;
      const status = axiosError.response?.status;
      const data = axiosError.response?.data;

      console.error(`[Buro API Error - ${context}]`, {
        status,
        data,
        message: axiosError.message,
      });

      return {
        success: false,
        error: data?.error?.mensaje || axiosError.message || "Error en API de Buró",
        code: data?.error?.codigo || `HTTP_${status}`,
        details: data,
      };
    }

    console.error(`[Buro API Error - ${context}]`, error);
    return {
      success: false,
      error: "Error desconocido al consultar API de Buró",
      code: "UNKNOWN_ERROR",
      details: error,
    };
  }

  /**
   * Consultar Autenticador
   */
  async authenticator(request: AuthenticatorRequest): Promise<{
    success: boolean;
    data?: BuroApiResponse;
    error?: string;
    code?: string;
  }> {
    try {
      const response = await axios.post(
        `${this.baseUrl}${BURO_API_CONFIG.endpoints.authenticator}`,
        request,
        {
          headers: this.getAuthHeaders(),
          timeout: 30000,
        }
      );

      return {
        success: true,
        data: response.data,
      };
    } catch (error) {
      return this.handleApiError(error, "AUTHENTICATOR");
    }
  }

  /**
   * Consultar Informe de Buró
   */
  async bureauReport(request: BureauReportRequest): Promise<{
    success: boolean;
    data?: BuroApiResponse;
    error?: string;
    code?: string;
  }> {
    try {
      const response = await axios.post(
        `${this.baseUrl}${BURO_API_CONFIG.endpoints.bureauReport}`,
        request,
        {
          headers: this.getAuthHeaders(),
          timeout: 30000,
        }
      );

      return {
        success: true,
        data: response.data,
      };
    } catch (error) {
      return this.handleApiError(error, "BUREAU_REPORT");
    }
  }

  /**
   * Consultar Estimador de Ingresos
   */
  async incomeEstimator(request: IncomeEstimatorRequest): Promise<{
    success: boolean;
    data?: BuroApiResponse;
    error?: string;
    code?: string;
  }> {
    try {
      const response = await axios.post(
        `${this.baseUrl}${BURO_API_CONFIG.endpoints.incomeEstimator}`,
        request,
        {
          headers: this.getAuthHeaders(),
          timeout: 30000,
        }
      );

      return {
        success: true,
        data: response.data,
      };
    } catch (error) {
      return this.handleApiError(error, "INCOME_ESTIMATOR");
    }
  }

  /**
   * Consultar Monitor
   */
  async monitor(request: any): Promise<{
    success: boolean;
    data?: BuroApiResponse;
    error?: string;
    code?: string;
  }> {
    try {
      const response = await axios.post(
        `${this.baseUrl}${BURO_API_CONFIG.endpoints.monitor}`,
        request,
        {
          headers: this.getAuthHeaders(),
          timeout: 30000,
        }
      );

      return {
        success: true,
        data: response.data,
      };
    } catch (error) {
      return this.handleApiError(error, "MONITOR");
    }
  }

  /**
   * Consultar Prospector
   */
  async prospector(request: any): Promise<{
    success: boolean;
    data?: BuroApiResponse;
    error?: string;
    code?: string;
  }> {
    try {
      const response = await axios.post(
        `${this.baseUrl}${BURO_API_CONFIG.endpoints.prospector}`,
        request,
        {
          headers: this.getAuthHeaders(),
          timeout: 30000,
        }
      );

      return {
        success: true,
        data: response.data,
      };
    } catch (error) {
      return this.handleApiError(error, "PROSPECTOR");
    }
  }

  /**
   * Consultar Reporte de Crédito
   */
  async creditReport(request: any): Promise<{
    success: boolean;
    data?: BuroApiResponse;
    error?: string;
    code?: string;
  }> {
    try {
      const response = await axios.post(
        `${this.baseUrl}${BURO_API_CONFIG.endpoints.creditReport}`,
        request,
        {
          headers: this.getAuthHeaders(),
          timeout: 30000,
        }
      );

      return {
        success: true,
        data: response.data,
      };
    } catch (error) {
      return this.handleApiError(error, "CREDIT_REPORT");
    }
  }

  /**
   * Validar RFC (formato básico)
   */
  validateRFC(rfc: string): boolean {
    // RFC debe tener 13 caracteres (personas físicas) o 12 (personas morales)
    // Formato: 6 letras + 6 dígitos + 3 caracteres alfanuméricos (opcional)
    const rfcRegex = /^[A-ZÑ&]{3,4}\d{6}[A-Z0-9]{3}$/i;
    return rfcRegex.test(rfc);
  }

  /**
   * Extraer score crediticio de respuesta
   */
  extractCreditScore(response: BuroApiResponse): number | null {
    return response.respuesta?.score || null;
  }

  /**
   * Determinar nivel de riesgo basado en score
   */
  determineRiskLevel(score: number | null): string {
    if (score === null) return "UNKNOWN";
    if (score >= 800) return "LOW";
    if (score >= 600) return "MEDIUM";
    return "HIGH";
  }
}

// Singleton instance
export const buroApiService = new BuroApiService();
