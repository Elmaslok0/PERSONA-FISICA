import { describe, expect, it, vi } from "vitest";
import { buroApiService } from "./buro-api-service";

describe("BuroApiService", () => {
  describe("validateRFC", () => {
    it("debe validar RFC válido de persona física", () => {
      const validRFC = "PEGJ900101XX1";
      expect(buroApiService.validateRFC(validRFC)).toBe(true);
    });

    it("debe validar RFC válido en minúsculas", () => {
      const validRFC = "pegj900101xx1";
      expect(buroApiService.validateRFC(validRFC)).toBe(true);
    });

    it("debe rechazar RFC inválido", () => {
      const invalidRFC = "INVALID";
      expect(buroApiService.validateRFC(invalidRFC)).toBe(false);
    });

    it("debe rechazar RFC vacío", () => {
      const emptyRFC = "";
      expect(buroApiService.validateRFC(emptyRFC)).toBe(false);
    });
  });

  describe("determineRiskLevel", () => {
    it("debe retornar LOW para score >= 800", () => {
      expect(buroApiService.determineRiskLevel(800)).toBe("LOW");
      expect(buroApiService.determineRiskLevel(850)).toBe("LOW");
    });

    it("debe retornar MEDIUM para score entre 600 y 799", () => {
      expect(buroApiService.determineRiskLevel(600)).toBe("MEDIUM");
      expect(buroApiService.determineRiskLevel(700)).toBe("MEDIUM");
      expect(buroApiService.determineRiskLevel(799)).toBe("MEDIUM");
    });

    it("debe retornar HIGH para score < 600", () => {
      expect(buroApiService.determineRiskLevel(599)).toBe("HIGH");
      expect(buroApiService.determineRiskLevel(400)).toBe("HIGH");
      expect(buroApiService.determineRiskLevel(0)).toBe("HIGH");
    });

    it("debe retornar UNKNOWN para score null", () => {
      expect(buroApiService.determineRiskLevel(null)).toBe("UNKNOWN");
    });
  });

  describe("extractCreditScore", () => {
    it("debe extraer score crediticio de respuesta", () => {
      const response = {
        respuesta: {
          score: 750,
        },
      };
      expect(buroApiService.extractCreditScore(response as any)).toBe(750);
    });

    it("debe retornar null si no hay score", () => {
      const response = {
        respuesta: {
          persona: { nombre: "Juan" },
        },
      };
      expect(buroApiService.extractCreditScore(response as any)).toBe(null);
    });

    it("debe retornar null si respuesta es vacía", () => {
      const response = {};
      expect(buroApiService.extractCreditScore(response as any)).toBe(null);
    });
  });
});
