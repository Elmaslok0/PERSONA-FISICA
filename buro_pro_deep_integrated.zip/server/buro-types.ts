export interface NombreBC {
  primerNombre: string;
  segundoNombre?: string;
  apellidoPaterno: string;
  apellidoMaterno?: string;
  fechaNacimiento?: string;
  rfc?: string;
  curp?: string;
  nacionalidad?: string;
  residencia?: string;
  estadoCivil?: string;
  sexo?: string;
  numeroDependientes?: string;
  numeroLicenciaConducir?: string;
  numeroRegistroElectoral?: string;
}

export interface Direccion {
  direccion1: string;
  direccion2?: string;
  coloniaPoblacion?: string;
  delegacionMunicipio: string;
  ciudad: string;
  estado: string;
  cp: string;
  fechaResidencia?: string;
  numeroTelefono?: string;
  tipoDomicilio?: string;
  indicadorEspecialDomicilio?: string;
}

export interface AutenticacionBC {
  tipoReporte: string;
  tipoSalidaAU: string;
  referenciaOperador: string;
  tarjetaCredito: string;
  ultimosCuatroDigitos?: string;
  ejercidoCreditoHipotecario: string;
  ejercidoCreditoAutomotriz: string;
}

export interface EncabezadoBC {
  numeroReferenciaOperador: string;
  claveUnidadMonetaria: string;
  idioma: string;
  tipoConsulta: string;
  tipoContrato: string;
  importeContrato?: string;
}

export interface BuroRequest {
  consulta: {
    persona: {
      nombre: NombreBC;
      domicilios: Direccion[];
      autentica?: AutenticacionBC;
      encabezado?: EncabezadoBC;
    };
  };
}
