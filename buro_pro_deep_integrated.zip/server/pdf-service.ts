import { PDFDocument, rgb } from "pdf-lib";
import { CreditReport } from "../drizzle/schema";

/**
 * Servicio para generar PDFs de reportes de crédito
 */
export class PdfService {
  /**
   * Generar PDF de reporte de crédito
   */
  static async generateReportPdf(report: CreditReport): Promise<Uint8Array> {
    const pdfDoc = await PDFDocument.create();
    const page = pdfDoc.addPage([612, 792]); // Letter size

    const { width, height } = page.getSize();
    const margin = 40;
    let yPosition = height - margin;

    // Helper para escribir texto
    const writeText = (
      text: string,
      size: number = 12,
      color: [number, number, number] = [0, 0, 0]
    ) => {
      page.drawText(text, {
        x: margin,
        y: yPosition,
        size,
        color: rgb(color[0] / 255, color[1] / 255, color[2] / 255),
      });
      yPosition -= size + 8;
    };

    // Header
    writeText("REPORTE DE CRÉDITO", 20, [25, 118, 210]);
    writeText("Panel de Buró de Crédito", 10, [100, 100, 100]);
    yPosition -= 10;

    // Línea separadora
    page.drawLine({
      start: { x: margin, y: yPosition },
      end: { x: width - margin, y: yPosition },
      thickness: 1,
      color: rgb(0.8, 0.8, 0.8),
    });
    yPosition -= 20;

    // Información Personal
    writeText("INFORMACIÓN PERSONAL", 14, [25, 118, 210]);
    writeText(`Nombre: ${report.firstName} ${report.lastName}`, 11);
    if (report.secondLastName) {
      writeText(`Apellido Materno: ${report.secondLastName}`, 11);
    }
    writeText(`RFC: ${report.rfc}`, 11);
    if (report.email) {
      writeText(`Correo: ${report.email}`, 11);
    }
    if (report.phone) {
      writeText(`Teléfono: ${report.phone}`, 11);
    }
    yPosition -= 10;

    // Dirección
    if (report.street || report.city) {
      writeText("DIRECCIÓN", 14, [25, 118, 210]);
      if (report.street) {
        writeText(`Calle: ${report.street}`, 11);
      }
      if (report.city) {
        writeText(`Ciudad: ${report.city}`, 11);
      }
      if (report.state) {
        writeText(`Estado: ${report.state}`, 11);
      }
      if (report.zipCode) {
        writeText(`Código Postal: ${report.zipCode}`, 11);
      }
      yPosition -= 10;
    }

    // Información del Reporte
    writeText("INFORMACIÓN DEL REPORTE", 14, [25, 118, 210]);
    writeText(`Tipo de Reporte: ${report.reportType}`, 11);
    writeText(`Estado: ${report.apiStatus}`, 11);
    if (report.creditScore) {
      writeText(`Score Crediticio: ${report.creditScore}`, 11);
    }
    if (report.riskLevel) {
      writeText(`Nivel de Riesgo: ${report.riskLevel}`, 11);
    }
    writeText(
      `Fecha: ${new Date(report.createdAt).toLocaleDateString("es-MX")}`,
      11
    );
    yPosition -= 10;

    // Resumen LLM si existe
    if (report.llmSummary) {
      writeText("RESUMEN EJECUTIVO", 14, [25, 118, 210]);
      const summary = report.llmSummary.substring(0, 500);
      writeText(summary, 10);
      yPosition -= 10;
    }

    // Footer
    yPosition = 40;
    page.drawText(
      `Generado: ${new Date().toLocaleString("es-MX")} | Referencia: ${report.id}`,
      {
        x: margin,
        y: yPosition,
        size: 8,
        color: rgb(0.6, 0.6, 0.6),
      }
    );

    return pdfDoc.save();
  }
}
