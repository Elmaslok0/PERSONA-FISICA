import { z } from "zod";
import { protectedProcedure, router } from "./_core/trpc";
import { creditReports } from "../drizzle/schema";
import { getDb } from "./db";
import { eq, desc, sql } from "drizzle-orm";
import { processReport } from "./process-report";

export const creditReportsRouter = router({
  create: protectedProcedure
    .input(
      z.object({
        firstName: z.string(),
        lastName: z.string(),
        rfc: z.string(),
        reportType: z.string(),
        payload: z.any(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      const [result] = await db.insert(creditReports).values({
        userId: ctx.user.id,
        firstName: input.firstName,
        lastName: input.lastName,
        rfc: input.rfc,
        reportType: input.reportType,
        requestPayload: input.payload,
        apiStatus: "PENDING",
      });

      const reportId = result.insertId;
      processReport(reportId).catch(console.error);
      return { id: reportId };
    }),

  list: protectedProcedure
    .input(z.object({ limit: z.number().optional().default(50) }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      return await db
        .select()
        .from(creditReports)
        .where(eq(creditReports.userId, ctx.user.id))
        .orderBy(desc(creditReports.createdAt))
        .limit(input.limit);
    }),

  getById: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = await getDb();
      const [report] = await db
        .select()
        .from(creditReports)
        .where(eq(creditReports.id, input.id));
      return report;
    }),

  getStatistics: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    const total = await db.select({ count: sql<number>`count(*)` }).from(creditReports).where(eq(creditReports.userId, ctx.user.id));
    const byStatus = await db.select({ status: creditReports.apiStatus, count: sql<number>`count(*)` }).from(creditReports).where(eq(creditReports.userId, ctx.user.id)).groupBy(creditReports.apiStatus);
    return {
      totalReports: total[0]?.count || 0,
      byStatus: Object.fromEntries(byStatus.map(s => [s.status || "UNKNOWN", s.count])),
    };
  }),
});
