import { eq } from "drizzle-orm";
import { creditReports } from "../drizzle/schema";
import { getDb } from "./db";
import { BURO_API_CONFIG } from "./buro-api-config";

export async function processReport(reportId: number) {
  const db = await getDb();
  const [report] = await db.select().from(creditReports).where(eq(creditReports.id, reportId));
  if (!report) return;

  try {
    console.log(`[BuroAPI] Processing ${report.reportType}`);
    await new Promise(resolve => setTimeout(resolve, 2000));

    const mockResponse = {
      status: "SUCCESS",
      data: {
        score: Math.floor(Math.random() * (850 - 300) + 300),
        riskLevel: ["LOW", "MEDIUM", "HIGH"][Math.floor(Math.random() * 3)],
      }
    };

    await db.update(creditReports).set({
      apiStatus: "SUCCESS",
      apiResponse: mockResponse,
      score: mockResponse.data.score,
      riskLevel: mockResponse.data.riskLevel,
    }).where(eq(creditReports.id, reportId));

  } catch (error: any) {
    await db.update(creditReports).set({ apiStatus: "ERROR" }).where(eq(creditReports.id, reportId));
  }
}
