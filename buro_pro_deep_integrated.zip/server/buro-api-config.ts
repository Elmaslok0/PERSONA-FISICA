export const BURO_API_CONFIG = {
  baseUrl: process.env.BURO_API_URL || "https://api.burodecredito.com.mx:4431/devpf",
  authUrl: "https://apigateway1.burodecredito.com.mx:8443/auth/oauth/v2/token",
  
  endpoints: {
    AUTHENTICATOR: "/autenticador/credit-report-api/v1/autenticador",
    INCOME_ESTIMATOR: "/estimador-ingresos/credit-report-api/v1/estimador-ingresos",
    BUREAU_REPORT: "/informe-buro/credit-report-api/v1/informe-buro",
    MONITOR: "/monitor/credit-report-api/v1/monitor",
    PROSPECTOR: "/prospector/credit-report-api/v1/prospector",
    CREDIT_REPORT: "/reporte-de-credito/credit-report-api/v1/reporte-de-credito",
  }
};
