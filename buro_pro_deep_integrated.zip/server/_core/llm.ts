import { ENV } from "./env";

export async function invokeLLM(params: any): Promise<any> {
  if (!ENV.forgeApiKey) {
    console.warn("[LLM] API Key missing, returning mock response");
    return {
      choices: [
        {
          message: {
            content: "## Resumen Ejecutivo\nEste es un análisis simulado porque no se configuró una API Key de LLM.\n\n## Riesgos Identificados\n- No se pudo realizar el análisis real.\n\n## Recomendaciones\n- Configura la variable BUILT_IN_FORGE_API_KEY para habilitar el análisis real."
          }
        }
      ]
    };
  }

  const url = ENV.forgeApiUrl && ENV.forgeApiUrl.trim().length > 0
    ? `${ENV.forgeApiUrl.replace(/\/$/, "")}/v1/chat/completions`
    : "https://forge.manus.im/v1/chat/completions";

  try {
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        authorization: `Bearer ${ENV.forgeApiKey}`,
      },
      body: JSON.stringify({
        model: "gemini-2.5-flash",
        messages: params.messages,
        max_tokens: 2000,
      }),
    });

    if (!response.ok) {
      throw new Error(`LLM invoke failed: ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    console.error("[LLM] Error:", error);
    return {
      choices: [{ message: { content: "Error al invocar el servicio de LLM." } }]
    };
  }
}
