import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import type { User } from "../../drizzle/schema";
import { sdk } from "./sdk";

export type TrpcContext = {
  req: CreateExpressContextOptions["req"];
  res: CreateExpressContextOptions["res"];
  user: User | null;
};

export async function createContext(
  opts: CreateExpressContextOptions
): Promise<TrpcContext> {
  let user: User | null = null;

  // MODO STANDALONE: Siempre autenticado en localhost
  // No requiere OAuth, funciona completamente offline
  const isLocalhost = 
    opts.req.hostname === "localhost" || 
    opts.req.hostname === "127.0.0.1" ||
    process.env.DEV_MODE === "true";

  if (isLocalhost) {
    user = {
      id: 1,
      openId: process.env.DEV_USER_ID || "standalone-user",
      name: process.env.DEV_USER_NAME || "Administrator",
      email: process.env.DEV_USER_EMAIL || "admin@localhost",
      loginMethod: "standalone",
      role: "admin",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    } as User;
    console.log("[STANDALONE MODE] Auto-authenticated as:", user.name);
  } else {
    try {
      user = await sdk.authenticateRequest(opts.req);
    } catch (error) {
      // Authentication is optional for public procedures.
      user = null;
    }
  }

  return {
    req: opts.req,
    res: opts.res,
    user,
  };
}
