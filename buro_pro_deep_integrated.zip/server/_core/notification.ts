import { TRPCError } from "@trpc/server";
import { ENV } from "./env";

export type NotificationPayload = {
  title: string;
  content: string;
};

export async function notifyOwner(
  payload: NotificationPayload
): Promise<boolean> {
  console.log("[Notification] Mock notification:", payload.title);
  
  if (!ENV.forgeApiUrl || !ENV.forgeApiKey) {
    console.warn("[Notification] Service not configured, skipping remote call");
    return true;
  }

  const endpoint = `${ENV.forgeApiUrl.endsWith("/") ? ENV.forgeApiUrl : ENV.forgeApiUrl + "/"}webdevtoken.v1.WebDevService/SendNotification`;
  
  try {
    const response = await fetch(endpoint, {
      method: "POST",
      headers: {
        accept: "application/json",
        authorization: `Bearer ${ENV.forgeApiKey}`,
        "content-type": "application/json",
        "connect-protocol-version": "1",
      },
      body: JSON.stringify(payload),
    });
    return response.ok;
  } catch (error) {
    console.warn("[Notification] Error calling notification service:", error);
    return false;
  }
}
