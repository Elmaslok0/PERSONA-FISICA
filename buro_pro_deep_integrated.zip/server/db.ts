import { eq } from "drizzle-orm";
import { drizzle as mysqlDrizzle } from "drizzle-orm/mysql2";
import { drizzle as sqliteDrizzle } from "drizzle-orm/better-sqlite3";
import Database from "better-sqlite3";
import * as schema from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: any = null;

export async function getDb() {
  if (!_db) {
    if (process.env.DATABASE_URL && process.env.DATABASE_URL.startsWith("mysql")) {
      try {
        _db = mysqlDrizzle(process.env.DATABASE_URL, { schema, mode: "default" });
        console.log("[Database] Connected to MySQL");
      } catch (error) {
        console.warn("[Database] Failed to connect to MySQL, falling back to SQLite in-memory:", error);
        const sqlite = new Database(":memory:");
        _db = sqliteDrizzle(sqlite, { schema });
      }
    } else {
      console.log("[Database] No DATABASE_URL found, using SQLite in-memory");
      const sqlite = new Database(":memory:");
      _db = sqliteDrizzle(sqlite, { schema });
    }
  }
  return _db;
}

export async function upsertUser(user: schema.InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }
  const db = await getDb();
  try {
    const values: schema.InsertUser = {
      openId: user.openId,
      name: user.name,
      email: user.email,
      loginMethod: user.loginMethod,
      role: user.role || (user.openId === ENV.ownerOpenId ? 'admin' : 'user'),
      lastSignedIn: new Date(),
    };
    
    // Check if user exists
    const existing = await db.select().from(schema.users).where(eq(schema.users.openId, user.openId)).limit(1);
    if (existing.length > 0) {
      await db.update(schema.users).set(values).where(eq(schema.users.openId, user.openId));
    } else {
      await db.insert(schema.users).values(values);
    }
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  const result = await db.select().from(schema.users).where(eq(schema.users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getCreditReports(filters?: any) {
  const db = await getDb();
  let query = db.select().from(schema.creditReports);
  
  // Basic filtering logic
  const results = await query;
  let filtered = results;
  
  if (filters?.userId) filtered = filtered.filter((r: any) => r.userId === filters.userId);
  if (filters?.reportType) filtered = filtered.filter((r: any) => r.reportType === filters.reportType);
  if (filters?.apiStatus) filtered = filtered.filter((r: any) => r.apiStatus === filters.apiStatus);
  if (filters?.riskLevel) filtered = filtered.filter((r: any) => r.riskLevel === filters.riskLevel);
  
  return filtered.sort((a: any, b: any) => b.createdAt.getTime() - a.createdAt.getTime())
    .slice(filters?.offset || 0, (filters?.offset || 0) + (filters?.limit || 50));
}

export async function getCreditReportById(id: number) {
  const db = await getDb();
  const result = await db.select().from(schema.creditReports).where(eq(schema.creditReports.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createCreditReport(data: schema.InsertCreditReport) {
  const db = await getDb();
  const result = await db.insert(schema.creditReports).values(data);
  return result;
}

export async function updateCreditReport(id: number, data: Partial<schema.InsertCreditReport>) {
  const db = await getDb();
  await db.update(schema.creditReports).set(data).where(eq(schema.creditReports.id, id));
}

export async function getReportStatistics(userId?: number) {
  const db = await getDb();
  const reports = await db.select().from(schema.creditReports);
  const filtered = userId ? reports.filter((r: any) => r.userId === userId) : reports;
  
  const byType: Record<string, number> = {};
  const byStatus: Record<string, number> = {};
  const byRisk: Record<string, number> = {};
  
  filtered.forEach((report: any) => {
    byType[report.reportType] = (byType[report.reportType] || 0) + 1;
    byStatus[report.apiStatus || "UNKNOWN"] = (byStatus[report.apiStatus || "UNKNOWN"] || 0) + 1;
    byRisk[report.riskLevel || "UNKNOWN"] = (byRisk[report.riskLevel || "UNKNOWN"] || 0) + 1;
  });
  
  return {
    totalReports: filtered.length,
    byType,
    byStatus,
    byRisk,
  };
}

export async function createAlert(data: schema.InsertAlert) {
  const db = await getDb();
  return await db.insert(schema.alerts).values(data);
}

export async function getUnresolvedAlerts(userId?: number) {
  const db = await getDb();
  let results = await db.select().from(schema.alerts).where(eq(schema.alerts.isResolved, 0));
  if (userId) results = results.filter((a: any) => a.userId === userId);
  return results;
}

export async function createAuditLog(data: schema.InsertAuditLog) {
  const db = await getDb();
  await db.insert(schema.auditLogs).values(data);
}
