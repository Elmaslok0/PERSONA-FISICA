import { useAuth } from "@/_core/hooks/useAuth";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarInset,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
  useSidebar,
} from "@/components/ui/sidebar";
import { useIsMobile } from "@/hooks/useMobile";
import { 
  LayoutDashboard, 
  LogOut, 
  PanelLeft, 
  FileText, 
  ShieldCheck, 
  TrendingUp, 
  Activity, 
  Search, 
  CreditCard,
  Settings,
  Bell
} from "lucide-react";
import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { DashboardLayoutSkeleton } from './DashboardLayoutSkeleton';

const menuItems = [
  { icon: LayoutDashboard, label: "Dashboard", path: "/" },
  { icon: FileText, label: "Reporte de Crédito", path: "/reporte-credito" },
  { icon: ShieldCheck, label: "Autenticador", path: "/autenticador" },
  { icon: TrendingUp, label: "Estimador de Ingresos", path: "/estimador-ingresos" },
  { icon: Activity, label: "Monitor", path: "/monitor" },
  { icon: Search, label: "Prospector", path: "/prospector" },
  { icon: CreditCard, label: "Informe Buró", path: "/informe-buro" },
  { icon: FileText, label: "Historial", path: "/reports" },
];

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const { loading, user, logout } = useAuth();
  const [location, setLocation] = useLocation();

  if (loading) {
    return <DashboardLayoutSkeleton />;
  }

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full bg-slate-950 text-slate-50">
        <AppSidebar user={user} logout={logout} location={location} setLocation={setLocation} />
        <SidebarInset className="flex flex-col bg-slate-950">
          <header className="flex h-16 items-center gap-4 border-b border-slate-800 px-6 sticky top-0 z-10 bg-slate-950/80 backdrop-blur-md">
            <SidebarTrigger className="text-slate-400 hover:text-white" />
            <div className="flex-1">
              <h1 className="text-lg font-semibold text-slate-200">
                {menuItems.find(item => item.path === location)?.label || "Panel de Crédito"}
              </h1>
            </div>
            <div className="flex items-center gap-4">
              <button className="p-2 text-slate-400 hover:text-white transition-colors">
                <Bell className="h-5 w-5" />
              </button>
              <button className="p-2 text-slate-400 hover:text-white transition-colors">
                <Settings className="h-5 w-5" />
              </button>
            </div>
          </header>
          <main className="flex-1 overflow-auto p-6">
            <div className="mx-auto max-w-7xl">
              {children}
            </div>
          </main>
        </SidebarInset>
      </div>
    </SidebarProvider>
  );
}

function AppSidebar({ user, logout, location, setLocation }: any) {
  const { isCollapsed } = useSidebar();

  return (
    <Sidebar collapsible="icon" className="border-r border-slate-800 bg-slate-900">
      <SidebarHeader className="h-16 flex items-center px-4 border-b border-slate-800">
        <div className="flex items-center gap-3 overflow-hidden">
          <div className="h-8 w-8 rounded-lg bg-blue-600 flex items-center justify-center shrink-0">
            <ShieldCheck className="h-5 w-5 text-white" />
          </div>
          {!isCollapsed && (
            <span className="font-bold text-xl tracking-tight text-white truncate">
              Buró<span className="text-blue-500">Pro</span>
            </span>
          )}
        </div>
      </SidebarHeader>
      <SidebarContent className="py-4">
        <SidebarMenu className="px-2 gap-1">
          {menuItems.map((item) => {
            const isActive = location === item.path;
            return (
              <SidebarMenuItem key={item.path}>
                <SidebarMenuButton
                  isActive={isActive}
                  onClick={() => setLocation(item.path)}
                  tooltip={item.label}
                  className={`
                    h-11 px-3 rounded-lg transition-all duration-200
                    ${isActive 
                      ? "bg-blue-600/10 text-blue-400 font-medium" 
                      : "text-slate-400 hover:bg-slate-800 hover:text-slate-200"}
                  `}
                >
                  <item.icon className={`h-5 w-5 ${isActive ? "text-blue-400" : ""}`} />
                  <span className="ml-3">{item.label}</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
            );
          })}
        </SidebarMenu>
      </SidebarContent>
      <SidebarFooter className="p-4 border-t border-slate-800">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="flex items-center gap-3 w-full p-2 rounded-xl hover:bg-slate-800 transition-colors group">
              <Avatar className="h-9 w-9 border border-slate-700">
                <AvatarFallback className="bg-slate-800 text-slate-200 text-xs">
                  {user?.name?.charAt(0).toUpperCase() || "A"}
                </AvatarFallback>
              </Avatar>
              {!isCollapsed && (
                <div className="flex-1 text-left overflow-hidden">
                  <p className="text-sm font-medium text-slate-200 truncate">{user?.name || "Admin"}</p>
                  <p className="text-xs text-slate-500 truncate">{user?.email || "admin@buro.com"}</p>
                </div>
              )}
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56 bg-slate-900 border-slate-800 text-slate-200">
            <DropdownMenuItem onClick={logout} className="text-red-400 focus:text-red-400 focus:bg-red-400/10 cursor-pointer">
              <LogOut className="mr-2 h-4 w-4" />
              <span>Cerrar Sesión</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </SidebarFooter>
    </Sidebar>
  );
}
