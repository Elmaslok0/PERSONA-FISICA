import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import NewReport from "./pages/NewReport";
import Reports from "./pages/Reports";
import ReportDetail from "./pages/ReportDetail";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/reporte-credito">
        <NewReport type="CREDIT_REPORT" />
      </Route>
      <Route path="/autenticador">
        <NewReport type="AUTHENTICATOR" />
      </Route>
      <Route path="/estimador-ingresos">
        <NewReport type="INCOME_ESTIMATOR" />
      </Route>
      <Route path="/monitor">
        <NewReport type="MONITOR" />
      </Route>
      <Route path="/prospector">
        <NewReport type="PROSPECTOR" />
      </Route>
      <Route path="/informe-buro">
        <NewReport type="BUREAU_REPORT" />
      </Route>
      <Route path="/reports" component={Reports} />
      <Route path="/report/:id" component={ReportDetail} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
