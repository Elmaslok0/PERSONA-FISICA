import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { ArrowLeft, Download, Loader2, AlertCircle, CheckCircle } from "lucide-react";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import { Streamdown } from "streamdown";

export default function ReportDetail({ params }: { params: { id: string } }) {
  const [, setLocation] = useLocation();
  const reportId = parseInt(params.id);

  const { data: report, isLoading } = trpc.creditReports.getById.useQuery(reportId);

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
        </div>
      </DashboardLayout>
    );
  }

  if (!report) {
    return (
      <DashboardLayout>
        <div className="max-w-2xl mx-auto">
          <Button
            variant="outline"
            className="mb-6 border-slate-600 hover:bg-slate-700"
            onClick={() => setLocation("/reports")}
          >
            <ArrowLeft size={16} className="mr-2" />
            Volver
          </Button>
          <Card className="bg-slate-800 border-slate-700">
            <CardContent className="py-12 text-center">
              <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
              <p className="text-slate-400">Reporte no encontrado</p>
            </CardContent>
          </Card>
        </div>
      </DashboardLayout>
    );
  }

  const apiResponse = report.apiResponse ? JSON.parse(report.apiResponse) : null;

  return (
    <DashboardLayout>
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <Button
            variant="outline"
            className="border-slate-600 hover:bg-slate-700"
            onClick={() => setLocation("/reports")}
          >
            <ArrowLeft size={16} className="mr-2" />
            Volver
          </Button>
          {report.pdfUrl && (
            <Button asChild className="bg-green-600 hover:bg-green-700">
              <a href={report.pdfUrl} target="_blank" rel="noopener noreferrer">
                <Download size={16} className="mr-2" />
                Descargar PDF
              </a>
            </Button>
          )}
        </div>

        {/* Header */}
        <Card className="bg-gradient-to-r from-blue-900/50 to-cyan-900/50 border-blue-700/50">
          <CardContent className="pt-6">
            <div className="flex items-start justify-between">
              <div>
                <h1 className="text-3xl font-bold text-white mb-2">
                  {report.firstName} {report.lastName}
                </h1>
                <p className="text-slate-300 mb-4">RFC: {report.rfc}</p>
                <div className="flex flex-wrap gap-2">
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-500/20 text-blue-300 border border-blue-500/30">
                    {report.reportType}
                  </span>
                  <span
                    className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${
                      report.apiStatus === "SUCCESS"
                        ? "bg-green-500/20 text-green-300 border border-green-500/30"
                        : report.apiStatus === "ERROR"
                        ? "bg-red-500/20 text-red-300 border border-red-500/30"
                        : "bg-yellow-500/20 text-yellow-300 border border-yellow-500/30"
                    }`}
                  >
                    {report.apiStatus}
                  </span>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm text-slate-400">
                  {format(new Date(report.createdAt), "dd MMM yyyy HH:mm", {
                    locale: es,
                  })}
                </p>
                {report.creditScore && (
                  <p className="text-3xl font-bold text-cyan-400 mt-2">{report.creditScore}</p>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Información Personal */}
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle>Información Personal</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-slate-400">Nombre Completo</p>
                <p className="text-white font-semibold">
                  {report.firstName} {report.lastName} {report.secondLastName || ""}
                </p>
              </div>
              <div>
                <p className="text-sm text-slate-400">RFC</p>
                <p className="text-white font-semibold">{report.rfc}</p>
              </div>
              {report.email && (
                <div>
                  <p className="text-sm text-slate-400">Correo Electrónico</p>
                  <p className="text-white font-semibold">{report.email}</p>
                </div>
              )}
              {report.phone && (
                <div>
                  <p className="text-sm text-slate-400">Teléfono</p>
                  <p className="text-white font-semibold">{report.phone}</p>
                </div>
              )}
            </div>

            {(report.street || report.city) && (
              <div className="mt-6 pt-6 border-t border-slate-700">
                <h4 className="font-semibold text-white mb-4">Dirección</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {report.street && (
                    <div>
                      <p className="text-sm text-slate-400">Calle</p>
                      <p className="text-white">{report.street}</p>
                    </div>
                  )}
                  {report.city && (
                    <div>
                      <p className="text-sm text-slate-400">Ciudad</p>
                      <p className="text-white">{report.city}</p>
                    </div>
                  )}
                  {report.state && (
                    <div>
                      <p className="text-sm text-slate-400">Estado</p>
                      <p className="text-white">{report.state}</p>
                    </div>
                  )}
                  {report.zipCode && (
                    <div>
                      <p className="text-sm text-slate-400">Código Postal</p>
                      <p className="text-white">{report.zipCode}</p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Análisis de Riesgo */}
        {report.riskLevel && (
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertCircle size={20} />
                Análisis de Riesgo
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4">
                <div
                  className={`px-4 py-2 rounded-lg font-semibold ${
                    report.riskLevel === "LOW"
                      ? "bg-green-500/20 text-green-300"
                      : report.riskLevel === "MEDIUM"
                      ? "bg-yellow-500/20 text-yellow-300"
                      : "bg-red-500/20 text-red-300"
                  }`}
                >
                  Nivel de Riesgo: {report.riskLevel}
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Resumen LLM */}
        {report.llmSummary && (
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle>Resumen Ejecutivo</CardTitle>
              <CardDescription className="text-slate-400">
                Análisis generado por IA
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Streamdown>{report.llmSummary}</Streamdown>
            </CardContent>
          </Card>
        )}

        {/* Riesgos Identificados */}
        {report.llmRisks && (
          <Card className="bg-red-900/20 border-red-700/50">
            <CardHeader>
              <CardTitle className="text-red-400 flex items-center gap-2">
                <AlertCircle size={20} />
                Riesgos Identificados
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Streamdown>{report.llmRisks}</Streamdown>
            </CardContent>
          </Card>
        )}

        {/* Recomendaciones */}
        {report.llmRecommendations && (
          <Card className="bg-green-900/20 border-green-700/50">
            <CardHeader>
              <CardTitle className="text-green-400 flex items-center gap-2">
                <CheckCircle size={20} />
                Recomendaciones
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Streamdown>{report.llmRecommendations}</Streamdown>
            </CardContent>
          </Card>
        )}

        {/* Respuesta API */}
        {apiResponse && (
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle>Datos del Reporte</CardTitle>
              <CardDescription className="text-slate-400">
                Información completa de la API
              </CardDescription>
            </CardHeader>
            <CardContent>
              <pre className="bg-slate-900 p-4 rounded-lg overflow-auto text-xs text-slate-300 max-h-96">
                {JSON.stringify(apiResponse, null, 2)}
              </pre>
            </CardContent>
          </Card>
        )}

        {/* Error Message */}
        {report.apiErrorMessage && (
          <Card className="bg-red-900/20 border-red-700/50">
            <CardHeader>
              <CardTitle className="text-red-400">Error en la Consulta</CardTitle>
            </CardHeader>
            <CardContent className="text-red-200">
              {report.apiErrorMessage}
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
}
