import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { 
  FileText, 
  ShieldCheck, 
  TrendingUp, 
  Activity, 
  Search, 
  CreditCard,
  ArrowRight,
  PlusCircle,
  Clock,
  AlertCircle
} from "lucide-react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";

const modules = [
  { 
    title: "Reporte de Crédito", 
    description: "Consulta transaccional completa", 
    icon: FileText, 
    path: "/reporte-credito",
    color: "bg-blue-500"
  },
  { 
    title: "Autenticador", 
    description: "Validación de identidad", 
    icon: ShieldCheck, 
    path: "/autenticador",
    color: "bg-emerald-500"
  },
  { 
    title: "Estimador de Ingresos", 
    description: "Cálculo de capacidad de pago", 
    icon: TrendingUp, 
    path: "/estimador-ingresos",
    color: "bg-purple-500"
  },
  { 
    title: "Monitor", 
    description: "Seguimiento de cambios", 
    icon: Activity, 
    path: "/monitor",
    color: "bg-orange-500"
  },
  { 
    title: "Prospector", 
    description: "Análisis predictivo", 
    icon: Search, 
    path: "/prospector",
    color: "bg-pink-500"
  },
  { 
    title: "Informe Buró", 
    description: "Historial crediticio detallado", 
    icon: CreditCard, 
    path: "/informe-buro",
    color: "bg-indigo-500"
  },
];

export default function Home() {
  const [, setLocation] = useLocation();
  const { data: stats } = trpc.creditReports.getStatistics.useQuery();

  return (
    <DashboardLayout>
      <div className="space-y-10 animate-in fade-in duration-700">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <h1 className="text-4xl font-extrabold text-white tracking-tight">Bienvenido al Panel de Crédito</h1>
            <p className="text-slate-400 mt-2 text-lg">Gestiona y consulta información crediticia de manera profesional.</p>
          </div>
          <Button 
            onClick={() => setLocation("/reporte-credito")}
            className="bg-blue-600 hover:bg-blue-700 text-white font-bold px-6 h-12 rounded-xl shadow-lg shadow-blue-600/20 transition-all active:scale-95"
          >
            <PlusCircle className="mr-2 h-5 w-5" />
            Nueva Consulta
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard 
            title="Total Consultas" 
            value={stats?.totalReports || 0} 
            icon={FileText} 
            color="text-blue-400"
          />
          <StatCard 
            title="Pendientes" 
            value={stats?.byStatus?.PENDING || 0} 
            icon={Clock} 
            color="text-amber-400"
          />
          <StatCard 
            title="Riesgo Alto" 
            value={stats?.byRisk?.HIGH || 0} 
            icon={AlertCircle} 
            color="text-red-400"
          />
          <StatCard 
            title="Completados" 
            value={stats?.byStatus?.SUCCESS || 0} 
            icon={ShieldCheck} 
            color="text-emerald-400"
          />
        </div>

        <div className="space-y-6">
          <h2 className="text-2xl font-bold text-white">Módulos Disponibles</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {modules.map((module) => (
              <Card 
                key={module.path}
                className="bg-slate-900 border-slate-800 hover:border-blue-500/50 transition-all duration-300 group cursor-pointer shadow-xl"
                onClick={() => setLocation(module.path)}
              >
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className={`h-12 w-12 rounded-xl ${module.color} flex items-center justify-center shadow-lg shadow-inner`}>
                      <module.icon className="h-6 w-6 text-white" />
                    </div>
                    <ArrowRight className="h-5 w-5 text-slate-600 group-hover:text-blue-400 transition-colors" />
                  </div>
                  <div className="mt-6">
                    <h3 className="text-xl font-bold text-white">{module.title}</h3>
                    <p className="text-slate-400 mt-2 text-sm leading-relaxed">{module.description}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}

function StatCard({ title, value, icon: Icon, color }: any) {
  return (
    <Card className="bg-slate-900 border-slate-800 shadow-xl overflow-hidden relative group">
      <div className="absolute -right-4 -bottom-4 opacity-5 group-hover:opacity-10 transition-opacity">
        <Icon className="h-24 w-24" />
      </div>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <p className="text-sm font-medium text-slate-400">{title}</p>
          <Icon className={`h-5 w-5 ${color}`} />
        </div>
        <div className="mt-4">
          <h3 className="text-3xl font-bold text-white">{value}</h3>
        </div>
      </CardContent>
    </Card>
  );
}
