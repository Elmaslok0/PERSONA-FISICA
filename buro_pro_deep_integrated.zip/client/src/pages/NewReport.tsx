import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { toast } from "sonner";
import { Loader2, ShieldCheck, User, MapPin, Mail, Phone, Send } from "lucide-react";

const REPORT_INFO: Record<string, { title: string; description: string; icon: any }> = {
  AUTHENTICATOR: { 
    title: "Autenticador", 
    description: "Validación de identidad de una persona física.",
    icon: ShieldCheck
  },
  BUREAU_REPORT: { 
    title: "Informe Buró", 
    description: "Historial crediticio detallado del cliente.",
    icon: User
  },
  INCOME_ESTIMATOR: { 
    title: "Estimador de Ingresos", 
    description: "Cálculo estimado de ingresos basado en comportamiento crediticio.",
    icon: TrendingUp
  },
  MONITOR: { 
    title: "Monitor", 
    description: "Seguimiento de cambios en el perfil crediticio.",
    icon: Activity
  },
  PROSPECTOR: { 
    title: "Prospector", 
    description: "Análisis predictivo para prospección de clientes.",
    icon: Search
  },
  CREDIT_REPORT: { 
    title: "Reporte de Crédito", 
    description: "Reporte transaccional completo de crédito.",
    icon: FileText
  },
};

import { TrendingUp, Activity, Search, FileText } from "lucide-react";

export default function NewReport({ type = "CREDIT_REPORT" }: { type?: string }) {
  const [, setLocation] = useLocation();
  const info = REPORT_INFO[type] || REPORT_INFO.CREDIT_REPORT;
  
  const [formData, setFormData] = useState({
    primerNombre: "",
    segundoNombre: "",
    apellidoPaterno: "",
    apellidoMaterno: "",
    rfc: "",
    direccion1: "",
    delegacionMunicipio: "",
    ciudad: "",
    estado: "CDMX",
    cp: "",
    tarjetaCredito: "F",
    ejercidoCreditoHipotecario: "F",
    ejercidoCreditoAutomotriz: "F",
  });

  const createMutation = trpc.creditReports.create.useMutation({
    onSuccess: () => {
      toast.success("Solicitud enviada a Buró de Crédito");
      setLocation("/reports");
    },
    onError: (e) => toast.error(e.message),
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const payload = {
      consulta: {
        persona: {
          nombre: {
            primerNombre: formData.primerNombre,
            segundoNombre: formData.segundoNombre || undefined,
            apellidoPaterno: formData.apellidoPaterno,
            apellidoMaterno: formData.apellidoMaterno || undefined,
            rfc: formData.rfc,
          },
          domicilios: [{
            direccion1: formData.direccion1,
            delegacionMunicipio: formData.delegacionMunicipio,
            ciudad: formData.ciudad,
            estado: formData.estado,
            cp: formData.cp,
          }],
          encabezado: {
            numeroReferenciaOperador: "REF-" + Date.now(),
            claveUnidadMonetaria: "MX",
            idioma: "SP",
            tipoConsulta: "I",
            tipoContrato: "CC",
          }
        }
      }
    };

    if (type === "AUTHENTICATOR") {
      (payload.consulta.persona as any).autentica = {
        tipoReporte: "RCN",
        tipoSalidaAU: "4",
        referenciaOperador: "AUTH-" + Date.now(),
        tarjetaCredito: formData.tarjetaCredito,
        ejercidoCreditoHipotecario: formData.ejercidoCreditoHipotecario,
        ejercidoCreditoAutomotriz: formData.ejercidoCreditoAutomotriz,
      };
    }

    createMutation.mutate({
      firstName: formData.primerNombre,
      lastName: formData.apellidoPaterno,
      rfc: formData.rfc,
      reportType: type,
      payload: payload,
    });
  };

  return (
    <DashboardLayout>
      <div className="max-w-5xl mx-auto space-y-8">
        <div className="flex items-center gap-4">
          <div className="h-14 w-14 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center shadow-2xl">
            <info.icon className={`h-7 w-7 ${info.color}`} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-white tracking-tight">{info.title}</h1>
            <p className="text-slate-400">Complete la información requerida por Buró de Crédito</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <Card className="bg-slate-900 border-slate-800 shadow-2xl">
              <CardHeader className="border-b border-slate-800/50">
                <CardTitle className="text-lg flex items-center gap-2 text-slate-200">
                  <User className="h-5 w-5 text-blue-500" /> Datos del Solicitante
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-6 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-slate-400">Primer Nombre *</Label>
                    <Input required value={formData.primerNombre} onChange={e => setFormData({...formData, primerNombre: e.target.value})} className="bg-slate-800 border-slate-700 text-white" />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-slate-400">Segundo Nombre</Label>
                    <Input value={formData.segundoNombre} onChange={e => setFormData({...formData, segundoNombre: e.target.value})} className="bg-slate-800 border-slate-700 text-white" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-slate-400">Apellido Paterno *</Label>
                    <Input required value={formData.apellidoPaterno} onChange={e => setFormData({...formData, apellidoPaterno: e.target.value})} className="bg-slate-800 border-slate-700 text-white" />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-slate-400">Apellido Materno</Label>
                    <Input value={formData.apellidoMaterno} onChange={e => setFormData({...formData, apellidoMaterno: e.target.value})} className="bg-slate-800 border-slate-700 text-white" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label className="text-slate-400">RFC *</Label>
                  <Input required placeholder="ABCD123456XYZ" value={formData.rfc} onChange={e => setFormData({...formData, rfc: e.target.value.toUpperCase()})} className="bg-slate-800 border-slate-700 text-white font-mono" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-900 border-slate-800 shadow-2xl">
              <CardHeader className="border-b border-slate-800/50">
                <CardTitle className="text-lg flex items-center gap-2 text-slate-200">
                  <MapPin className="h-5 w-5 text-emerald-500" /> Domicilio
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-6 space-y-4">
                <div className="space-y-2">
                  <Label className="text-slate-400">Calle y Número *</Label>
                  <Input required value={formData.direccion1} onChange={e => setFormData({...formData, direccion1: e.target.value})} className="bg-slate-800 border-slate-700 text-white" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-slate-400">Delegación / Municipio *</Label>
                    <Input required value={formData.delegacionMunicipio} onChange={e => setFormData({...formData, delegacionMunicipio: e.target.value})} className="bg-slate-800 border-slate-700 text-white" />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-slate-400">Ciudad *</Label>
                    <Input required value={formData.ciudad} onChange={e => setFormData({...formData, ciudad: e.target.value})} className="bg-slate-800 border-slate-700 text-white" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-slate-400">Estado *</Label>
                    <Select value={formData.estado} onValueChange={v => setFormData({...formData, estado: v})}>
                      <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-slate-900 border-slate-800 text-white">
                        {ESTADOS_MEXICO.map(e => <SelectItem key={e.val} value={e.val}>{e.label}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label className="text-slate-400">Código Postal *</Label>
                    <Input required maxLength={5} value={formData.cp} onChange={e => setFormData({...formData, cp: e.target.value})} className="bg-slate-800 border-slate-700 text-white" />
                  </div>
                </div>
              </CardContent>
            </Card>

            {type === "AUTHENTICATOR" && (
              <Card className="bg-slate-900 border-slate-800 shadow-2xl border-l-4 border-l-emerald-500">
                <CardHeader className="border-b border-slate-800/50">
                  <CardTitle className="text-lg flex items-center gap-2 text-slate-200">
                    <ShieldCheck className="h-5 w-5 text-emerald-500" /> Preguntas de Autenticación
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-6 space-y-6">
                  <div className="flex items-center justify-between p-4 bg-slate-800/50 rounded-xl">
                    <Label className="text-slate-200">¿Tiene tarjeta de crédito vigente?</Label>
                    <Select value={formData.tarjetaCredito} onValueChange={v => setFormData({...formData, tarjetaCredito: v})}>
                      <SelectTrigger className="w-32 bg-slate-900 border-slate-700 text-white"><SelectValue /></SelectTrigger>
                      <SelectContent className="bg-slate-900 border-slate-800 text-white">
                        <SelectItem value="V">Sí</SelectItem>
                        <SelectItem value="F">No</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex items-center justify-between p-4 bg-slate-800/50 rounded-xl">
                    <Label className="text-slate-200">¿Tiene crédito hipotecario?</Label>
                    <Select value={formData.ejercidoCreditoHipotecario} onValueChange={v => setFormData({...formData, ejercidoCreditoHipotecario: v})}>
                      <SelectTrigger className="w-32 bg-slate-900 border-slate-700 text-white"><SelectValue /></SelectTrigger>
                      <SelectContent className="bg-slate-900 border-slate-800 text-white">
                        <SelectItem value="V">Sí</SelectItem>
                        <SelectItem value="F">No</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex items-center justify-between p-4 bg-slate-800/50 rounded-xl">
                    <Label className="text-slate-200">¿Tiene crédito automotriz?</Label>
                    <Select value={formData.ejercidoCreditoAutomotriz} onValueChange={v => setFormData({...formData, ejercidoCreditoAutomotriz: v})}>
                      <SelectTrigger className="w-32 bg-slate-900 border-slate-700 text-white"><SelectValue /></SelectTrigger>
                      <SelectContent className="bg-slate-900 border-slate-800 text-white">
                        <SelectItem value="V">Sí</SelectItem>
                        <SelectItem value="F">No</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          <div className="space-y-6">
            <Card className="bg-blue-600 border-none text-white shadow-2xl overflow-hidden relative">
              <div className="absolute top-0 right-0 p-4 opacity-10"><Send className="h-24 w-24 rotate-12" /></div>
              <CardHeader><CardTitle>Confirmar Solicitud</CardTitle></CardHeader>
              <CardContent className="space-y-6 relative z-10">
                <div className="p-4 bg-white/10 rounded-2xl backdrop-blur-md border border-white/10">
                  <p className="text-xs text-blue-100 uppercase font-bold tracking-wider">Módulo</p>
                  <p className="text-xl font-bold mt-1">{info.title}</p>
                </div>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between border-b border-white/10 pb-2">
                    <span className="text-blue-100">Costo de consulta:</span>
                    <span className="font-bold">1 Crédito</span>
                  </div>
                  <div className="flex justify-between border-b border-white/10 pb-2">
                    <span className="text-blue-100">Respuesta estimada:</span>
                    <span className="font-bold">Inmediata</span>
                  </div>
                </div>
                <Button type="submit" disabled={createMutation.isPending} className="w-full bg-white text-blue-600 hover:bg-blue-50 font-bold h-14 rounded-2xl shadow-2xl transition-all active:scale-95">
                  {createMutation.isPending ? <Loader2 className="h-6 w-6 animate-spin" /> : "Procesar en Buró"}
                </Button>
              </CardContent>
            </Card>
          </div>
        </form>
      </div>
    </DashboardLayout>
  );
}
