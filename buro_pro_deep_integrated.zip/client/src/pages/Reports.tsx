import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { FileText, Search, Filter, Download, Eye, AlertCircle, CheckCircle2, Clock } from "lucide-react";
import { format } from "date-fns";
import { es } from "date-fns/locale";

export default function Reports() {
  const [, setLocation] = useLocation();
  const { data: reports, isLoading } = trpc.creditReports.list.useQuery({});

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "SUCCESS":
        return <Badge className="bg-emerald-500/10 text-emerald-500 border-emerald-500/20 gap-1"><CheckCircle2 className="h-3 w-3" /> Completado</Badge>;
      case "ERROR":
        return <Badge className="bg-red-500/10 text-red-500 border-red-500/20 gap-1"><AlertCircle className="h-3 w-3" /> Error</Badge>;
      case "PENDING":
        return <Badge className="bg-amber-500/10 text-amber-500 border-amber-500/20 gap-1"><Clock className="h-3 w-3" /> Procesando</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getRiskBadge = (risk: string) => {
    switch (risk) {
      case "LOW":
        return <Badge className="bg-emerald-500 text-white">Bajo</Badge>;
      case "MEDIUM":
        return <Badge className="bg-amber-500 text-white">Medio</Badge>;
      case "HIGH":
        return <Badge className="bg-red-500 text-white">Alto</Badge>;
      default:
        return <span className="text-slate-500">-</span>;
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-8 animate-in fade-in duration-500">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-white">Historial de Consultas</h1>
            <p className="text-slate-400 mt-1">Visualiza y gestiona todos los reportes generados.</p>
          </div>
          <div className="flex gap-3">
            <Button variant="outline" className="bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800">
              <Filter className="mr-2 h-4 w-4" />
              Filtros
            </Button>
            <Button variant="outline" className="bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800">
              <Download className="mr-2 h-4 w-4" />
              Exportar
            </Button>
          </div>
        </div>

        <Card className="bg-slate-900 border-slate-800 shadow-2xl overflow-hidden">
          <CardContent className="p-0">
            <Table>
              <TableHeader className="bg-slate-800/50">
                <TableRow className="border-slate-800 hover:bg-transparent">
                  <TableHead className="text-slate-300 font-bold py-4">Fecha</TableHead>
                  <TableHead className="text-slate-300 font-bold">Cliente</TableHead>
                  <TableHead className="text-slate-300 font-bold">RFC</TableHead>
                  <TableHead className="text-slate-300 font-bold">Tipo</TableHead>
                  <TableHead className="text-slate-300 font-bold">Estado</TableHead>
                  <TableHead className="text-slate-300 font-bold">Riesgo</TableHead>
                  <TableHead className="text-slate-300 font-bold text-right">Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <TableRow key={i} className="border-slate-800">
                      <TableCell colSpan={7} className="h-16 animate-pulse bg-slate-800/20" />
                    </TableRow>
                  ))
                ) : reports?.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="h-64 text-center">
                      <div className="flex flex-col items-center justify-center text-slate-500">
                        <FileText className="h-12 w-12 mb-4 opacity-20" />
                        <p className="text-lg font-medium">No se encontraron reportes</p>
                        <Button 
                          variant="link" 
                          className="text-blue-400 mt-2"
                          onClick={() => setLocation("/reporte-credito")}
                        >
                          Realizar primera consulta
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ) : (
                  reports?.map((report: any) => (
                    <TableRow key={report.id} className="border-slate-800 hover:bg-slate-800/30 transition-colors group">
                      <TableCell className="py-4 text-slate-300">
                        {format(new Date(report.createdAt), "dd MMM, yyyy", { locale: es })}
                      </TableCell>
                      <TableCell>
                        <div className="font-medium text-white">{report.firstName} {report.lastName}</div>
                        <div className="text-xs text-slate-500">{report.email || "Sin correo"}</div>
                      </TableCell>
                      <TableCell className="font-mono text-xs text-slate-400">{report.rfc}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="bg-slate-800 border-slate-700 text-slate-400 font-normal">
                          {report.reportType}
                        </Badge>
                      </TableCell>
                      <TableCell>{getStatusBadge(report.apiStatus)}</TableCell>
                      <TableCell>{getRiskBadge(report.riskLevel)}</TableCell>
                      <TableCell className="text-right">
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="text-slate-400 hover:text-blue-400 hover:bg-blue-400/10"
                          onClick={() => setLocation(`/report/${report.id}`)}
                        >
                          <Eye className="h-4 w-4 mr-2" />
                          Ver
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
