# Instalación en Windows - Panel de Buró de Crédito

## ⚠️ REQUISITOS PREVIOS OBLIGATORIOS

### 1. Node.js (REQUERIDO)
**Descargar e instalar ANTES de continuar:**
- URL: https://nodejs.org/ (versión LTS recomendada)
- **IMPORTANTE:** Durante la instalación, marca la opción "Add to PATH"
- Reinicia Windows después de instalar

**Verificar instalación:**
```cmd
node --version
npm --version
```

## 📋 PASOS DE INSTALACIÓN

### Opción A: Instalación Automática (Recomendado)

1. **Descomprimir el ZIP** en una carpeta
2. **Abrir CMD en esa carpeta:**
   - Click derecho en la carpeta
   - Seleccionar "Abrir en Terminal" o "Abrir aquí en CMD"
3. **Ejecutar el instalador:**
   ```cmd
   install.bat
   ```
4. **Esperar a que termine** (puede tomar 10-15 minutos)
5. **Iniciar el servidor:**
   ```cmd
   start-dev.bat
   ```

### Opción B: Instalación Manual

1. **Descomprimir el ZIP**
2. **Abrir CMD en la carpeta del proyecto**
3. **Ejecutar estos comandos en orden:**

```cmd
REM Instalar pnpm globalmente
npm install -g pnpm

REM Instalar dependencias
pnpm install

REM Compilar
pnpm check

REM Iniciar servidor
pnpm dev
```

## 🔧 CONFIGURACIÓN DE VARIABLES DE ENTORNO

Crear archivo `.env.local` en la raíz del proyecto:

```env
# Base de datos (ajusta según tu setup)
DATABASE_URL=mysql://usuario:contraseña@localhost:3306/buro_credit

# OAuth Manus
VITE_APP_ID=tu_app_id
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://manus.im/login

# APIs de Buró de Crédito
BURO_API_KEY=l7f4ab9619923343069e3a48c3209b61e4
BURO_API_SECRET=ee9ba699e9f54cd7bbe7948e0884ccc9
BURO_API_URL=https://api.buro.com

# LLM
BUILT_IN_FORGE_API_KEY=tu_llm_key
BUILT_IN_FORGE_API_URL=https://api.manus.im

# S3
AWS_ACCESS_KEY_ID=tu_access_key
AWS_SECRET_ACCESS_KEY=tu_secret_key
AWS_REGION=us-east-1
AWS_S3_BUCKET=tu_bucket
```

## 🚀 EJECUTAR EL PROYECTO

### Desarrollo
```cmd
pnpm dev
```
Acceder a: **http://localhost:3000**

### Producción
```cmd
REM Compilar
pnpm build

REM Ejecutar
pnpm start
```

## 📝 COMANDOS DISPONIBLES

```cmd
pnpm dev              # Servidor de desarrollo
pnpm build            # Compilar para producción
pnpm start            # Ejecutar en producción
pnpm test             # Ejecutar tests
pnpm check            # Verificar tipos TypeScript
pnpm format           # Formatear código
pnpm db:push          # Actualizar base de datos
```

## ❌ SOLUCIÓN DE PROBLEMAS

### Error: "pnpm no está instalado"
```cmd
npm install -g pnpm
```

### Error: "node no está reconocido"
- Node.js no está en PATH
- Solución: Reinstalar Node.js marcando "Add to PATH"
- Reiniciar Windows

### Error: "Puerto 3000 en uso"
```cmd
REM Cambiar puerto en server/_core/index.ts
REM Busca: app.listen(3000
REM Cambia a: app.listen(3001
```

### Error: "Permisos denegados"
- Ejecutar CMD como Administrador
- Click derecho en CMD → "Ejecutar como administrador"

### Error: "Base de datos no conecta"
- Verificar DATABASE_URL en .env.local
- Asegurar que MySQL está corriendo
- Ejecutar: `pnpm db:push`

### Limpiar caché y reinstalar
```cmd
REM Eliminar node_modules
rmdir /s /q node_modules

REM Reinstalar
pnpm install
```

## 📁 ESTRUCTURA DEL PROYECTO

```
buro_credit_panel/
├── client/              # Frontend React
│   └── src/pages/       # Páginas principales
├── server/              # Backend Express + tRPC
├── drizzle/             # Base de datos
├── install.bat          # Instalador
├── start-dev.bat        # Iniciar desarrollo
└── build-prod.bat       # Compilar producción
```

## 🔐 SEGURIDAD

- Nunca commits `.env.local` al repositorio
- Mantén las API keys seguras
- Usa variables de entorno para credenciales

## 📞 SOPORTE

Si tienes problemas:
1. Verifica que Node.js está instalado: `node --version`
2. Verifica que pnpm está instalado: `pnpm --version`
3. Intenta limpiar caché: `pnpm install`
4. Reinicia Windows

---

**Versión:** 1.0.0  
**Última actualización:** Enero 2026
