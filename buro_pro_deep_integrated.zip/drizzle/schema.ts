import { mysqlTable, serial, varchar, text, timestamp, int, json } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  openId: varchar("open_id", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 255 }),
  createdAt: timestamp("created_at").defaultNow(),
});

export const creditReports = mysqlTable("credit_reports", {
  id: serial("id").primaryKey(),
  userId: int("user_id").notNull(),
  firstName: varchar("first_name", { length: 255 }).notNull(),
  lastName: varchar("last_name", { length: 255 }).notNull(),
  rfc: varchar("rfc", { length: 20 }).notNull(),
  reportType: varchar("report_type", { length: 50 }).notNull(),
  requestPayload: json("request_payload").notNull(),
  apiStatus: varchar("api_status", { length: 50 }).default("PENDING"),
  apiResponse: json("api_response"),
  riskLevel: varchar("risk_level", { length: 20 }),
  score: int("score"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow(),
});
