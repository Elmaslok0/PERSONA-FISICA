CREATE TABLE `alerts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`reportId` int NOT NULL,
	`userId` int NOT NULL,
	`alertType` varchar(50) NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`severity` varchar(50) NOT NULL,
	`isResolved` int DEFAULT 0,
	`resolvedAt` timestamp,
	`resolvedBy` int,
	`resolutionNotes` text,
	`notificationSent` int DEFAULT 0,
	`notificationSentAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `alerts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `audit_logs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`action` varchar(100) NOT NULL,
	`resourceType` varchar(50),
	`resourceId` int,
	`details` text,
	`ipAddress` varchar(45),
	`userAgent` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `audit_logs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `credit_reports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`firstName` varchar(100) NOT NULL,
	`lastName` varchar(100) NOT NULL,
	`secondLastName` varchar(100),
	`rfc` varchar(20) NOT NULL,
	`email` varchar(320),
	`phone` varchar(20),
	`street` varchar(255),
	`city` varchar(100),
	`state` varchar(100),
	`zipCode` varchar(10),
	`country` varchar(100),
	`reportType` varchar(50) NOT NULL,
	`apiResponse` text,
	`apiStatus` varchar(50),
	`apiErrorMessage` text,
	`referenceId` varchar(255),
	`creditScore` int,
	`riskLevel` varchar(50),
	`pdfUrl` varchar(500),
	`pdfKey` varchar(500),
	`llmSummary` text,
	`llmRisks` text,
	`llmRecommendations` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `credit_reports_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `alerts` ADD CONSTRAINT `alerts_reportId_credit_reports_id_fk` FOREIGN KEY (`reportId`) REFERENCES `credit_reports`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `alerts` ADD CONSTRAINT `alerts_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `alerts` ADD CONSTRAINT `alerts_resolvedBy_users_id_fk` FOREIGN KEY (`resolvedBy`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `audit_logs` ADD CONSTRAINT `audit_logs_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `credit_reports` ADD CONSTRAINT `credit_reports_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;