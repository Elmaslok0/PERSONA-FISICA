CREATE TABLE `buro_consultas` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`rfc` varchar(13) NOT NULL,
	`tipoCliente` enum('PM','PF') NOT NULL,
	`modulos` varchar(255) NOT NULL,
	`status` enum('pending','success','error') DEFAULT 'pending',
	`resultados` json,
	`error` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `buro_consultas_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `buro_reportes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`consultaId` int NOT NULL,
	`nombre` varchar(255) NOT NULL,
	`tipo` enum('informeBuro','rco','prospector') NOT NULL,
	`contenido` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `buro_reportes_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `buro_scores` (
	`id` int AUTO_INCREMENT NOT NULL,
	`consultaId` int NOT NULL,
	`rfc` varchar(13) NOT NULL,
	`codigoScore` varchar(50) NOT NULL,
	`valorScore` varchar(50),
	`referenciaConsultado` varchar(255),
	`codigoRazon1` varchar(50),
	`codigoRazon2` varchar(50),
	`codigoRazon3` varchar(50),
	`codigoRazon4` varchar(50),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `buro_scores_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `buro_consultas` ADD CONSTRAINT `buro_consultas_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `buro_reportes` ADD CONSTRAINT `buro_reportes_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `buro_reportes` ADD CONSTRAINT `buro_reportes_consultaId_buro_consultas_id_fk` FOREIGN KEY (`consultaId`) REFERENCES `buro_consultas`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `buro_scores` ADD CONSTRAINT `buro_scores_consultaId_buro_consultas_id_fk` FOREIGN KEY (`consultaId`) REFERENCES `buro_consultas`(`id`) ON DELETE cascade ON UPDATE no action;