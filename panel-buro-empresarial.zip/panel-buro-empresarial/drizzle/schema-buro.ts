/**
 * Esquema de base de datos para consultas de Buró Empresarial
 */

import {
  int,
  json,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/mysql-core";
import { users } from "./schema";

/**
 * Tabla para almacenar consultas realizadas a las APIs de Buró
 */
export const buroConsultas = mysqlTable("buro_consultas", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  rfc: varchar("rfc", { length: 13 }).notNull(),
  tipoCliente: mysqlEnum("tipoCliente", ["PM", "PF"]).notNull(),
  modulos: varchar("modulos", { length: 255 }).notNull(), // JSON string: ["informeBuro", "rco", "prospector"]
  status: mysqlEnum("status", ["pending", "success", "error"]).default("pending"),
  resultados: json("resultados"), // Almacena los resultados de las APIs
  error: text("error"), // Mensaje de error si la consulta falló
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/**
 * Tabla para almacenar reportes generados
 */
export const buroReportes = mysqlTable("buro_reportes", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  consultaId: int("consultaId")
    .notNull()
    .references(() => buroConsultas.id, { onDelete: "cascade" }),
  nombre: varchar("nombre", { length: 255 }).notNull(),
  tipo: mysqlEnum("tipo", ["informeBuro", "rco", "prospector"]).notNull(),
  contenido: json("contenido"), // Datos del reporte
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

/**
 * Tabla para almacenar historial de scores
 */
export const buroScores = mysqlTable("buro_scores", {
  id: int("id").autoincrement().primaryKey(),
  consultaId: int("consultaId")
    .notNull()
    .references(() => buroConsultas.id, { onDelete: "cascade" }),
  rfc: varchar("rfc", { length: 13 }).notNull(),
  codigoScore: varchar("codigoScore", { length: 50 }).notNull(),
  valorScore: varchar("valorScore", { length: 50 }),
  referenciaConsultado: varchar("referenciaConsultado", { length: 255 }),
  codigoRazon1: varchar("codigoRazon1", { length: 50 }),
  codigoRazon2: varchar("codigoRazon2", { length: 50 }),
  codigoRazon3: varchar("codigoRazon3", { length: 50 }),
  codigoRazon4: varchar("codigoRazon4", { length: 50 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type BuroConsulta = typeof buroConsultas.$inferSelect;
export type InsertBuroConsulta = typeof buroConsultas.$inferInsert;

export type BuroReporte = typeof buroReportes.$inferSelect;
export type InsertBuroReporte = typeof buroReportes.$inferInsert;

export type BuroScore = typeof buroScores.$inferSelect;
export type InsertBuroScore = typeof buroScores.$inferInsert;
