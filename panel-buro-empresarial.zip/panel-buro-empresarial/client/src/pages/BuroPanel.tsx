/**
 * Panel principal de consulta de Buró Empresarial
 */

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { trpc } from "@/lib/trpc";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, AlertCircle, CheckCircle2 } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";

// Esquema de validación local
const ConsultaPorRFCSchema = z.object({
  rfc: z.string().min(1, "RFC es requerido"),
  tipoCliente: z.enum(["PM", "PF"]).default("PM"),
  modulos: z
    .array(z.enum(["informeBuro", "rco", "prospector"]))
    .default(["informeBuro", "rco", "prospector"]),
});

type ConsultaPorRFC = z.infer<typeof ConsultaPorRFCSchema>;

export function BuroPanel() {
  const { user, isAuthenticated, loading: authLoading } = useAuth({
    redirectOnUnauthenticated: true,
  });

  const [resultados, setResultados] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const consultarMutation = trpc.buro.consultarPorRFC.useMutation();
  const historialQuery = trpc.buro.historialConsultas.useQuery({ limit: 10 });

  const form = useForm<ConsultaPorRFC>({
    resolver: zodResolver(ConsultaPorRFCSchema) as any,
    defaultValues: {
      rfc: "",
      tipoCliente: "PM",
      modulos: ["informeBuro", "rco", "prospector"],
    },
  });

  const onSubmit = async (data: ConsultaPorRFC) => {
    setIsLoading(true);
    setError(null);
    setResultados(null);

    try {
      const response = await consultarMutation.mutateAsync(data);
      setResultados(response);

      if (response.status === "error") {
        setError("Hubo un error al consultar las APIs de Buró");
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Error desconocido");
    } finally {
      setIsLoading(false);
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-slate-900 mb-2">
            Panel de Buró Empresarial
          </h1>
          <p className="text-slate-600">
            Consulta el buró y score de empresas de forma rápida y segura
          </p>
          {user && (
            <p className="text-sm text-slate-500 mt-2">
              Bienvenido, {user.name || user.email}
            </p>
          )}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Formulario de búsqueda */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Consultar Empresa</CardTitle>
                <CardDescription>
                  Ingresa el RFC de la empresa para obtener su información de buró
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    {/* RFC */}
                    <FormField
                      control={form.control}
                      name="rfc"
                      render={({ field }: any) => (
                        <FormItem>
                          <FormLabel>RFC</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="Ej: ABC123456XYZ"
                              {...field}
                              disabled={isLoading}
                              className="uppercase"
                            />
                          </FormControl>
                          <FormDescription>
                            Registro Federal de Contribuyentes (13 caracteres)
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Tipo de Cliente */}
                    <FormField
                      control={form.control}
                      name="tipoCliente"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Tipo de Cliente</FormLabel>
                          <Select value={field.value} onValueChange={field.onChange}>
                            <FormControl>
                              <SelectTrigger disabled={isLoading}>
                                <SelectValue />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="PM">Persona Moral</SelectItem>
                              <SelectItem value="PF">Persona Física</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Módulos a consultar */}
                    <FormItem>
                      <FormLabel>Módulos a Consultar</FormLabel>
                      <div className="space-y-3 mt-3">
                        {[
                          { id: "informeBuro", label: "Informe Buró" },
                          { id: "rco", label: "Reporte de Crédito (RCO)" },
                          { id: "prospector", label: "Prospector" },
                        ].map((modulo) => (
                          <FormField
                            key={modulo.id}
                            control={form.control}
                            name="modulos"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                                <FormControl>
                                  <Checkbox
                                    checked={field.value?.includes(modulo.id as any)}
                                    onCheckedChange={(checked) => {
                                      const current = field.value || [];
                                      if (checked) {
                                        field.onChange([...current, modulo.id]);
                                      } else {
                                        field.onChange(
                                          current.filter((v) => v !== modulo.id)
                                        );
                                      }
                                    }}
                                    disabled={isLoading}
                                  />
                                </FormControl>
                                <FormLabel className="font-normal cursor-pointer">
                                  {modulo.label}
                                </FormLabel>
                              </FormItem>
                            )}
                          />
                        ))}
                      </div>
                    </FormItem>

                    {/* Error */}
                    {error && (
                      <Alert variant="destructive">
                        <AlertCircle className="h-4 w-4" />
                        <AlertDescription>{error}</AlertDescription>
                      </Alert>
                    )}

                    {/* Botón de envío */}
                    <Button
                      type="submit"
                      disabled={isLoading}
                      className="w-full"
                      size="lg"
                    >
                      {isLoading ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Consultando...
                        </>
                      ) : (
                        "Consultar"
                      )}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </div>

          {/* Panel lateral - Historial */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Historial Reciente</CardTitle>
              </CardHeader>
              <CardContent>
                {historialQuery.isLoading ? (
                  <div className="flex justify-center py-4">
                    <Loader2 className="h-4 w-4 animate-spin" />
                  </div>
                ) : historialQuery.data && historialQuery.data.length > 0 ? (
                  <div className="space-y-2">
                    {historialQuery.data.map((consulta: any) => (
                      <div
                        key={consulta.id}
                        className="p-3 bg-slate-50 rounded-lg border border-slate-200 hover:bg-slate-100 cursor-pointer transition"
                      >
                        <div className="font-mono text-sm font-semibold text-slate-900">
                          {consulta.rfc}
                        </div>
                        <div className="text-xs text-slate-500 mt-1">
                          {new Date(consulta.createdAt).toLocaleDateString("es-MX")}
                        </div>
                        <div className="flex items-center mt-2">
                          {consulta.status === "success" ? (
                            <CheckCircle2 className="h-3 w-3 text-green-600 mr-1" />
                          ) : (
                            <AlertCircle className="h-3 w-3 text-red-600 mr-1" />
                          )}
                          <span className="text-xs text-slate-600">
                            {consulta.status === "success" ? "Exitosa" : "Error"}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-slate-500 text-center py-4">
                    No hay consultas recientes
                  </p>
                )}
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Resultados */}
        {resultados && (
          <div className="mt-8">
            <Card>
              <CardHeader>
                <CardTitle>Resultados de la Consulta</CardTitle>
                <CardDescription>
                  RFC: {resultados.rfc} | Estado: {resultados.status}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="informeBuro" className="w-full">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="informeBuro">Informe Buró</TabsTrigger>
                    <TabsTrigger value="rco">RCO</TabsTrigger>
                    <TabsTrigger value="prospector">Prospector</TabsTrigger>
                  </TabsList>

                  {/* Tab: Informe Buró */}
                  <TabsContent value="informeBuro" className="space-y-4">
                    {resultados.resultados?.informeBuro ? (
                      <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
                        <pre className="text-xs overflow-auto max-h-96">
                          {JSON.stringify(resultados.resultados.informeBuro, null, 2)}
                        </pre>
                      </div>
                    ) : (
                      <Alert>
                        <AlertDescription>
                          No se consultó este módulo
                        </AlertDescription>
                      </Alert>
                    )}
                  </TabsContent>

                  {/* Tab: RCO */}
                  <TabsContent value="rco" className="space-y-4">
                    {resultados.resultados?.rco ? (
                      <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
                        <pre className="text-xs overflow-auto max-h-96">
                          {JSON.stringify(resultados.resultados.rco, null, 2)}
                        </pre>
                      </div>
                    ) : (
                      <Alert>
                        <AlertDescription>
                          No se consultó este módulo
                        </AlertDescription>
                      </Alert>
                    )}
                  </TabsContent>

                  {/* Tab: Prospector */}
                  <TabsContent value="prospector" className="space-y-4">
                    {resultados.resultados?.prospector ? (
                      <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
                        <pre className="text-xs overflow-auto max-h-96">
                          {JSON.stringify(resultados.resultados.prospector, null, 2)}
                        </pre>
                      </div>
                    ) : (
                      <Alert>
                        <AlertDescription>
                          No se consultó este módulo
                        </AlertDescription>
                      </Alert>
                    )}
                  </TabsContent>
                </Tabs>

                {/* Scores */}
                {resultados.scores && resultados.scores.length > 0 && (
                  <div className="mt-6">
                    <h3 className="font-semibold text-slate-900 mb-3">Scores Obtenidos</h3>
                    <div className="space-y-2">
                      {resultados.scores.map((score: any, idx: number) => (
                        <div
                          key={idx}
                          className="p-3 bg-blue-50 border border-blue-200 rounded-lg"
                        >
                          <div className="font-semibold text-blue-900">
                            {score.codigoScore}: {score.valorScore}
                          </div>
                          <div className="text-sm text-blue-700 mt-1">
                            Referencia: {score.referenciaConsultado}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}

export default BuroPanel;
