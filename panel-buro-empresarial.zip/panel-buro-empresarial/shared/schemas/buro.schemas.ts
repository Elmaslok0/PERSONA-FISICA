/**
 * Esquemas Zod compartidos para validación de datos de Buró
 */

import { z } from "zod";

// Esquema para Datos Generales (común en todas las APIs)
export const DatosGeneralesRequestSchema = z.object({
  rfc: z.string().min(1, "RFC es requerido"),
  tipoCliente: z.enum(["PM", "PF"]).default("PM"),
  apellidoPaterno: z.string().optional(),
  apellidoMaterno: z.string().optional(),
  primerNombre: z.string().optional(),
  segundoNombre: z.string().optional(),
  curp: z.string().optional(),
  domicilio: z
    .object({
      direccion: z.string().optional(),
      coloniaOPoblacion: z.string().optional(),
      ciudad: z.string().optional(),
      alcaldiaOMunicipio: z.string().optional(),
      estado: z.string().optional(),
      codigoPostal: z.string().optional(),
      pais: z.string().optional(),
    })
    .optional(),
});

// Esquema para Accionista
export const AccionistaRequestSchema = z.object({
  identificadorUnico: z.string().optional(),
  primerNombre: z.string().optional(),
  segundoNombre: z.string().optional(),
  apellidoPaterno: z.string().optional(),
  apellidoMaterno: z.string().optional(),
  apellidoAdicional: z.string().optional(),
  rfc: z.string().optional(),
  curp: z.string().optional(),
  fechaNacimiento: z.string().optional(),
  nacionalidad: z.string().default("MX"),
  pais: z.string().default("MX"),
  direccion1: z.string().optional(),
  direccion2: z.string().optional(),
  colonia: z.string().optional(),
  ciudad: z.string().optional(),
  delegacion: z.string().optional(),
  nombreEstado: z.string().optional(),
  codigoPostal: z.string().optional(),
});

// Esquema para Score
export const ScoreRequestSchema = z.object({
  identificadorUnico: z.string().optional(),
  primerNombre: z.string().optional(),
  segundoNombre: z.string().optional(),
  apellidoPaterno: z.string().optional(),
  apellidoMaterno: z.string().optional(),
  rfc: z.string().optional(),
  curp: z.string().optional(),
  fechaNacimiento: z.string().optional(),
  nacionalidad: z.string().default("MX"),
  pais: z.string().default("MX"),
  direccion1: z.string().optional(),
  colonia: z.string().optional(),
  ciudad: z.string().optional(),
  delegacion: z.string().optional(),
  nombreEstado: z.string().optional(),
  codigoPostal: z.string().optional(),
});

// Esquema para Consulta de Informe Buró
export const ConsultaInformeBuroSchema = z.object({
  datosGenerales: DatosGeneralesRequestSchema,
  accionista: z.array(AccionistaRequestSchema).optional(),
  score: z.array(ScoreRequestSchema).optional(),
  hawk: z
    .object({
      codigoHawk: z.string().optional(),
      descripcionPrevencionHawk: z.string().optional(),
      fechaMensajeHawk: z.string().optional(),
      usuarioReporta: z.string().optional(),
    })
    .optional(),
});

// Esquema para Consulta de RCO
export const ConsultaRCOSchema = z.object({
  datosGenerales: DatosGeneralesRequestSchema,
  accionista: z.array(AccionistaRequestSchema).optional(),
  score: z.array(ScoreRequestSchema).optional(),
});

// Esquema para Consulta de Prospector
export const ConsultaProspectorSchema = z.object({
  datosGenerales: DatosGeneralesRequestSchema,
  accionista: z.array(AccionistaRequestSchema).optional(),
  score: z.array(ScoreRequestSchema).optional(),
});

// Esquema para consulta simple por RFC
export const ConsultaPorRFCSchema = z.object({
  rfc: z.string().min(1, "RFC es requerido"),
  tipoCliente: z.enum(["PM", "PF"]).default("PM"),
  modulos: z
    .array(z.enum(["informeBuro", "rco", "prospector"]))
    .default(["informeBuro", "rco", "prospector"]),
});

export type DatosGeneralesRequest = z.infer<typeof DatosGeneralesRequestSchema>;
export type AccionistaRequest = z.infer<typeof AccionistaRequestSchema>;
export type ScoreRequest = z.infer<typeof ScoreRequestSchema>;
export type ConsultaInformeBuro = z.infer<typeof ConsultaInformeBuroSchema>;
export type ConsultaRCO = z.infer<typeof ConsultaRCOSchema>;
export type ConsultaProspector = z.infer<typeof ConsultaProspectorSchema>;
export type ConsultaPorRFC = z.infer<typeof ConsultaPorRFCSchema>;
