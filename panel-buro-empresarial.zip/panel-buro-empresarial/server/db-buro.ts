/**
 * Funciones de base de datos para operaciones de Buró Empresarial
 */

import { eq, desc } from "drizzle-orm";
import { getDb } from "./db";
import {
  buroConsultas,
  buroReportes,
  buroScores,
  InsertBuroConsulta,
  InsertBuroReporte,
  InsertBuroScore,
} from "../drizzle/schema-buro";

/**
 * Crea una nueva consulta de Buró
 */
export async function createBuroConsulta(
  data: InsertBuroConsulta
): Promise<number> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const result = await db.insert(buroConsultas).values(data);
  return result[0].insertId;
}

/**
 * Obtiene una consulta de Buró por ID
 */
export async function getBuroConsulta(consultaId: number) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const result = await db
    .select()
    .from(buroConsultas)
    .where(eq(buroConsultas.id, consultaId))
    .limit(1);

  return result.length > 0 ? result[0] : null;
}

/**
 * Actualiza el estado y resultados de una consulta
 */
export async function updateBuroConsulta(
  consultaId: number,
  data: {
    status?: "pending" | "success" | "error";
    resultados?: unknown;
    error?: string;
  }
) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const updateData: Record<string, unknown> = {
    updatedAt: new Date(),
  };

  if (data.status) updateData.status = data.status;
  if (data.resultados) updateData.resultados = data.resultados;
  if (data.error) updateData.error = data.error;

  await db
    .update(buroConsultas)
    .set(updateData)
    .where(eq(buroConsultas.id, consultaId));
}

/**
 * Obtiene todas las consultas de un usuario
 */
export async function getUserBuroConsultas(userId: number, limit = 50) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  return await db
    .select()
    .from(buroConsultas)
    .where(eq(buroConsultas.userId, userId))
    .orderBy(desc(buroConsultas.createdAt))
    .limit(limit);
}

/**
 * Crea un reporte de Buró
 */
export async function createBuroReporte(
  data: InsertBuroReporte
): Promise<number> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const result = await db.insert(buroReportes).values(data);
  return result[0].insertId;
}

/**
 * Obtiene reportes de una consulta
 */
export async function getBuroReportes(consultaId: number) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  return await db
    .select()
    .from(buroReportes)
    .where(eq(buroReportes.consultaId, consultaId))
    .orderBy(desc(buroReportes.createdAt));
}

/**
 * Crea registros de scores
 */
export async function createBuroScores(
  scores: InsertBuroScore[]
): Promise<void> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  if (scores.length > 0) {
    await db.insert(buroScores).values(scores);
  }
}

/**
 * Obtiene scores de una consulta
 */
export async function getBuroScoresByConsulta(consultaId: number) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  return await db
    .select()
    .from(buroScores)
    .where(eq(buroScores.consultaId, consultaId))
    .orderBy(desc(buroScores.createdAt));
}

/**
 * Obtiene el score más reciente de un RFC
 */
export async function getLatestScoreByRFC(rfc: string) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const result = await db
    .select()
    .from(buroScores)
    .where(eq(buroScores.rfc, rfc))
    .orderBy(desc(buroScores.createdAt))
    .limit(1);

  return result.length > 0 ? result[0] : null;
}
