/**
 * Router de tRPC para consultas de Buró Empresarial
 */

import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { getBuroApiClient } from "../apis/buro.client";
import {
  ConsultaPorRFCSchema,
  ConsultaInformeBuroSchema,
  ConsultaRCOSchema,
  ConsultaProspectorSchema,
} from "../apis/buro.schemas";
import {
  createBuroConsulta,
  getBuroConsulta,
  updateBuroConsulta,
  getUserBuroConsultas,
  createBuroScores,
  getBuroScoresByConsulta,
  getLatestScoreByRFC,
} from "../db-buro";
import { protectedProcedure, router } from "./trpc";

export const buroRouter = router({
  /**
   * Consulta simple por RFC - obtiene todos los módulos
   */
  consultarPorRFC: protectedProcedure
    .input(ConsultaPorRFCSchema)
    .mutation(async ({ input, ctx }) => {
      try {
        const { rfc, tipoCliente, modulos } = input;

        // Crear registro de consulta
        const consultaId = await createBuroConsulta({
          userId: ctx.user.id,
          rfc,
          tipoCliente,
          modulos: JSON.stringify(modulos),
          status: "pending",
        });

        // Preparar datos de consulta
        const consultaData = {
          datosGenerales: {
            rfc,
            tipoCliente,
          },
        };

        // Obtener resultados de las APIs
        const client = getBuroApiClient();
        const results = await client.getMultipleReports(
          consultaData,
          modulos as any
        );

        // Procesar resultados
        const resultadosFinales: Record<string, any> = {};
        const scores: any[] = [];
        let hasError = false;
        let errorMessage = "";

        for (const [module, response] of Object.entries(results)) {
          if (response.success && response.data) {
            resultadosFinales[module] = response.data;

            // Extraer scores si existen
            const respData = response.data as any;
            if (respData?.respuesta?.score) {
              respData.respuesta.score.forEach((score: any) => {
                scores.push({
                  consultaId,
                  rfc,
                  codigoScore: score.codigoScore,
                  valorScore: score.valorScore,
                  referenciaConsultado: score.referenciaConsultado,
                  codigoRazon1: score.codigoRazon1,
                  codigoRazon2: score.codigoRazon2,
                  codigoRazon3: score.codigoRazon3,
                  codigoRazon4: score.codigoRazon4,
                });
              });
            }
          } else {
            hasError = true;
            errorMessage = response.error || "Error desconocido";
            resultadosFinales[module] = {
              error: response.error,
              statusCode: response.statusCode,
            };
          }
        }

        // Guardar scores
        if (scores.length > 0) {
          await createBuroScores(scores);
        }

        // Actualizar consulta con resultados
        await updateBuroConsulta(consultaId, {
          status: hasError ? "error" : "success",
          resultados: resultadosFinales,
          error: hasError ? errorMessage : undefined,
        });

        return {
          consultaId,
          rfc,
          resultados: resultadosFinales,
          scores,
          status: hasError ? "error" : "success",
        };
      } catch (error) {
        console.error("[buroRouter] Error en consultarPorRFC:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: error instanceof Error ? error.message : "Error desconocido",
        });
      }
    }),

  /**
   * Consulta detallada de Informe Buró
   */
  consultarInformeBuro: protectedProcedure
    .input(ConsultaInformeBuroSchema)
    .mutation(async ({ input, ctx }) => {
      try {
        const rfc = input.datosGenerales.rfc;
        const tipoCliente = input.datosGenerales.tipoCliente;

        // Crear registro de consulta
        const consultaId = await createBuroConsulta({
          userId: ctx.user.id,
          rfc,
          tipoCliente,
          modulos: JSON.stringify(["informeBuro"]),
          status: "pending",
        });

        // Obtener resultado
        const client = getBuroApiClient();
        const response = await client.getInformeBuro(input);

        // Procesar scores
        const scores: any[] = [];
        const responseData = response.data as any;
        if (responseData?.respuesta?.score) {
          responseData.respuesta.score.forEach((score: any) => {
            scores.push({
              consultaId,
              rfc,
              codigoScore: score.codigoScore,
              valorScore: score.valorScore,
              referenciaConsultado: score.referenciaConsultado,
              codigoRazon1: score.codigoRazon1,
              codigoRazon2: score.codigoRazon2,
              codigoRazon3: score.codigoRazon3,
              codigoRazon4: score.codigoRazon4,
            });
          });
        }

        // Guardar scores
        if (scores.length > 0) {
          await createBuroScores(scores);
        }

        // Actualizar consulta
        await updateBuroConsulta(consultaId, {
          status: response.success ? "success" : "error",
          resultados: response.data,
          error: response.success ? undefined : response.error,
        });

        return {
          consultaId,
          rfc,
          resultado: response.data,
          scores,
          status: response.success ? "success" : "error",
        };
      } catch (error) {
        console.error("[buroRouter] Error en consultarInformeBuro:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: error instanceof Error ? error.message : "Error desconocido",
        });
      }
    }),

  /**
   * Consulta detallada de RCO
   */
  consultarRCO: protectedProcedure
    .input(ConsultaRCOSchema)
    .mutation(async ({ input, ctx }) => {
      try {
        const rfc = input.datosGenerales.rfc;
        const tipoCliente = input.datosGenerales.tipoCliente;

        // Crear registro de consulta
        const consultaId = await createBuroConsulta({
          userId: ctx.user.id,
          rfc,
          tipoCliente,
          modulos: JSON.stringify(["rco"]),
          status: "pending",
        });

        // Obtener resultado
        const client = getBuroApiClient();
        const response = await client.getRCO(input);

        // Procesar scores
        const scores: any[] = [];
        const responseData = response.data as any;
        if (responseData?.respuesta?.score) {
          responseData.respuesta.score.forEach((score: any) => {
            scores.push({
              consultaId,
              rfc,
              codigoScore: score.codigoScore,
              valorScore: score.valorScore,
              referenciaConsultado: score.referenciaConsultado,
              codigoRazon1: score.codigoRazon1,
              codigoRazon2: score.codigoRazon2,
              codigoRazon3: score.codigoRazon3,
              codigoRazon4: score.codigoRazon4,
            });
          });
        }

        // Guardar scores
        if (scores.length > 0) {
          await createBuroScores(scores);
        }

        // Actualizar consulta
        await updateBuroConsulta(consultaId, {
          status: response.success ? "success" : "error",
          resultados: response.data,
          error: response.success ? undefined : response.error,
        });

        return {
          consultaId,
          rfc,
          resultado: response.data,
          scores,
          status: response.success ? "success" : "error",
        };
      } catch (error) {
        console.error("[buroRouter] Error en consultarRCO:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: error instanceof Error ? error.message : "Error desconocido",
        });
      }
    }),

  /**
   * Consulta detallada de Prospector
   */
  consultarProspector: protectedProcedure
    .input(ConsultaProspectorSchema)
    .mutation(async ({ input, ctx }) => {
      try {
        const rfc = input.datosGenerales.rfc;
        const tipoCliente = input.datosGenerales.tipoCliente;

        // Crear registro de consulta
        const consultaId = await createBuroConsulta({
          userId: ctx.user.id,
          rfc,
          tipoCliente,
          modulos: JSON.stringify(["prospector"]),
          status: "pending",
        });

        // Obtener resultado
        const client = getBuroApiClient();
        const response = await client.getProspector(input);

        // Procesar scores
        const scores: any[] = [];
        const responseData = response.data as any;
        if (responseData?.respuesta?.score) {
          responseData.respuesta.score.forEach((score: any) => {
            scores.push({
              consultaId,
              rfc,
              codigoScore: score.codigoScore,
              valorScore: score.valorScore,
              referenciaConsultado: score.referenciaConsultado,
              codigoRazon1: score.codigoRazon1,
              codigoRazon2: score.codigoRazon2,
              codigoRazon3: score.codigoRazon3,
              codigoRazon4: score.codigoRazon4,
            });
          });
        }

        // Guardar scores
        if (scores.length > 0) {
          await createBuroScores(scores);
        }

        // Actualizar consulta
        await updateBuroConsulta(consultaId, {
          status: response.success ? "success" : "error",
          resultados: response.data,
          error: response.success ? undefined : response.error,
        });

        return {
          consultaId,
          rfc,
          resultado: response.data,
          scores,
          status: response.success ? "success" : "error",
        };
      } catch (error) {
        console.error("[buroRouter] Error en consultarProspector:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: error instanceof Error ? error.message : "Error desconocido",
        });
      }
    }),

  /**
   * Obtiene el historial de consultas del usuario
   */
  historialConsultas: protectedProcedure
    .input(z.object({ limit: z.number().default(50) }))
    .query(async ({ input, ctx }) => {
      try {
        return await getUserBuroConsultas(ctx.user.id, input.limit);
      } catch (error) {
        console.error("[buroRouter] Error en historialConsultas:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: error instanceof Error ? error.message : "Error desconocido",
        });
      }
    }),

  /**
   * Obtiene detalles de una consulta específica
   */
  obtenerConsulta: protectedProcedure
    .input(z.object({ consultaId: z.number() }))
    .query(async ({ input, ctx }) => {
      try {
        const consulta = await getBuroConsulta(input.consultaId);

        if (!consulta || consulta.userId !== ctx.user.id) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Consulta no encontrada",
          });
        }

        const scores = await getBuroScoresByConsulta(input.consultaId);

        return {
          ...consulta,
          modulos: JSON.parse(consulta.modulos),
          scores,
        };
      } catch (error) {
        console.error("[buroRouter] Error en obtenerConsulta:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: error instanceof Error ? error.message : "Error desconocido",
        });
      }
    }),

  /**
   * Obtiene el score más reciente de un RFC
   */
  obtenerScorePorRFC: protectedProcedure
    .input(z.object({ rfc: z.string() }))
    .query(async ({ input }) => {
      try {
        return await getLatestScoreByRFC(input.rfc);
      } catch (error) {
        console.error("[buroRouter] Error en obtenerScorePorRFC:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: error instanceof Error ? error.message : "Error desconocido",
        });
      }
    }),
});
