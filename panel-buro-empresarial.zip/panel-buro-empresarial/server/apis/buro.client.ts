/**
 * Cliente HTTP para las APIs de Buró Empresarial
 * Maneja autenticación OAuth2 y llamadas a los tres módulos
 */

import axios, { AxiosInstance } from "axios";
import { BURO_API_CONFIG, BuroApiModule } from "./buro.config";

interface TokenResponse {
  access_token: string;
  token_type: string;
  expires_in: number;
}

interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  statusCode: number;
}

class BuroApiClient {
  private axiosInstance: AxiosInstance;
  private accessToken: string | null = null;
  private tokenExpiry: number | null = null;

  constructor() {
    this.axiosInstance = axios.create({
      timeout: BURO_API_CONFIG.timeout,
      headers: {
        "Content-Type": "application/json",
      },
    });
  }

  /**
   * Obtiene un token de acceso OAuth2
   */
  private async getAccessToken(): Promise<string> {
    // Si tenemos un token válido, lo retornamos
    if (this.accessToken && this.tokenExpiry && Date.now() < this.tokenExpiry) {
      return this.accessToken;
    }

    try {
      const response = await axios.post<TokenResponse>(
        BURO_API_CONFIG.oauth.tokenEndpoint,
        {
          grant_type: BURO_API_CONFIG.oauth.grantType,
          client_id: BURO_API_CONFIG.clientId,
          client_secret: BURO_API_CONFIG.clientSecret,
        },
        {
          timeout: BURO_API_CONFIG.timeout,
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
        }
      );

      this.accessToken = response.data.access_token;
      // Establecer expiración 5 minutos antes del tiempo real
      this.tokenExpiry = Date.now() + (response.data.expires_in - 300) * 1000;

      return this.accessToken;
    } catch (error) {
      console.error("[BuroApiClient] Error obtaining access token:", error);
      throw new Error("Failed to obtain access token from Buró API");
    }
  }

  /**
   * Realiza una llamada a una API de Buró con reintentos
   */
  private async callWithRetry<T>(
    fn: () => Promise<T>,
    retries = BURO_API_CONFIG.maxRetries
  ): Promise<T> {
    try {
      return await fn();
    } catch (error) {
      if (retries > 0) {
        console.warn(
          `[BuroApiClient] Request failed, retrying... (${BURO_API_CONFIG.maxRetries - retries + 1}/${BURO_API_CONFIG.maxRetries})`
        );
        await new Promise((resolve) =>
          setTimeout(resolve, BURO_API_CONFIG.retryDelay)
        );
        return this.callWithRetry(fn, retries - 1);
      }
      throw error;
    }
  }

  /**
   * Consulta el Informe Buró de una empresa
   */
  async getInformeBuro(consulta: unknown): Promise<ApiResponse<unknown>> {
    return this.callWithRetry(async () => {
      const token = await this.getAccessToken();
      const config = BURO_API_CONFIG.endpoints.informeBuro;

      const response = await this.axiosInstance.post(
        `${config.baseUrl}${config.path}`,
        consulta,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      return {
        success: true,
        data: response.data,
        statusCode: response.status,
      };
    });
  }

  /**
   * Consulta el Reporte de Crédito (RCO) de una empresa
   */
  async getRCO(consulta: unknown): Promise<ApiResponse<unknown>> {
    return this.callWithRetry(async () => {
      const token = await this.getAccessToken();
      const config = BURO_API_CONFIG.endpoints.rco;

      const response = await this.axiosInstance.post(
        `${config.baseUrl}${config.path}`,
        consulta,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      return {
        success: true,
        data: response.data,
        statusCode: response.status,
      };
    });
  }

  /**
   * Consulta el Prospector de una empresa
   */
  async getProspector(consulta: unknown): Promise<ApiResponse<unknown>> {
    return this.callWithRetry(async () => {
      const token = await this.getAccessToken();
      const config = BURO_API_CONFIG.endpoints.prospector;

      const response = await this.axiosInstance.post(
        `${config.baseUrl}${config.path}`,
        consulta,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      return {
        success: true,
        data: response.data,
        statusCode: response.status,
      };
    });
  }

  /**
   * Realiza consultas a múltiples módulos simultáneamente
   */
  async getMultipleReports(
    consulta: unknown,
    modules: BuroApiModule[]
  ): Promise<Record<BuroApiModule, ApiResponse<unknown>>> {
    const results: Record<string, ApiResponse<unknown>> = {};

    const promises = modules.map(async (module) => {
      try {
        let response: ApiResponse<unknown>;

        switch (module) {
          case "informeBuro":
            response = await this.getInformeBuro(consulta);
            break;
          case "rco":
            response = await this.getRCO(consulta);
            break;
          case "prospector":
            response = await this.getProspector(consulta);
            break;
          default:
            response = {
              success: false,
              error: `Unknown module: ${module}`,
              statusCode: 400,
            };
        }

        results[module] = response;
      } catch (error) {
        results[module] = {
          success: false,
          error: error instanceof Error ? error.message : "Unknown error",
          statusCode: 500,
        };
      }
    });

    await Promise.all(promises);

    return results as Record<BuroApiModule, ApiResponse<unknown>>;
  }
}

// Singleton instance
let clientInstance: BuroApiClient | null = null;

export function getBuroApiClient(): BuroApiClient {
  if (!clientInstance) {
    clientInstance = new BuroApiClient();
  }
  return clientInstance;
}

export type { ApiResponse };
