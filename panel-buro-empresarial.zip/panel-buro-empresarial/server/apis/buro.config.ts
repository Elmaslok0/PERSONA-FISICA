/**
 * Configuración de las APIs de Buró Empresarial
 * Integra los tres módulos: Informe Buró, RCO y Prospector
 */

export const BURO_API_CONFIG = {
  // Credenciales de cliente
  clientId: process.env.BURO_CLIENT_ID || "l7b2cfae8956824957988b466ecdf62454",
  clientSecret: process.env.BURO_CLIENT_SECRET || "c98475ee018c41b798f8b14f51c58920",

  // Endpoints de las APIs
  endpoints: {
    // Informe Buró API
    informeBuro: {
      baseUrl: "https://api.burodecredito.com.mx:4431/devpm/informe-buro",
      path: "/pm-report/api/v1/reporte-informe-buro",
      description: "Permite obtener Datos transaccionales (Informe Buró)",
    },
    // Reporte de Crédito (RCO) API
    rco: {
      baseUrl: "https://api.burodecredito.com.mx:4431/devpm/reporte-de-credito",
      path: "/pm-report/api/v1/reporte-de-credito",
      description: "Permite obtener Datos transaccionales (Reporte de Crédito)",
    },
    // Prospector API
    prospector: {
      baseUrl: "https://api.burodecredito.com.mx:4431/devpm/prospector",
      path: "/pm-report/api/v1/reporte-prospector",
      description: "Permite obtener Datos transaccionales (Prospector)",
    },
  },

  // Configuración de autenticación OAuth2
  oauth: {
    type: "oauth2",
    tokenEndpoint: "https://api.burodecredito.com.mx:4431/oauth/token",
    grantType: "client_credentials",
  },

  // Configuración de timeout y reintentos
  timeout: 30000, // 30 segundos
  maxRetries: 3,
  retryDelay: 1000, // 1 segundo
};

export type BuroApiModule = "informeBuro" | "rco" | "prospector";
